// Vendor Controller
const fs = require('fs');
const path = require('path');

// Path to vendors data file
const vendorsFilePath = path.join(__dirname, '../data/vendors.json');

// Helper function to read vendors from file
const readVendorsFromFile = () => {
    try {
        const data = fs.readFileSync(vendorsFilePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading vendors file:', error);
        return [];
    }
};

// Helper function to write vendors to file
const writeVendorsToFile = (vendors) => {
    try {
        fs.writeFileSync(vendorsFilePath, JSON.stringify(vendors, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing vendors file:', error);
        return false;
    }
};

// Helper function to generate new ID
const generateNewId = (vendors) => {
    return vendors.length > 0 ? Math.max(...vendors.map(v => v.id)) + 1 : 1;
};

// Helper function to validate email format
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

// GET all vendors
const getAllVendors = (req, res) => {
    try {
        const vendors = readVendorsFromFile();
        
        // Handle query parameters for filtering and pagination
        const { category, isActive, city, state, page = 1, limit = 10 } = req.query;
        
        let filteredVendors = vendors;
        
        // Filter by category
        if (category) {
            filteredVendors = filteredVendors.filter(vendor => 
                vendor.category.toLowerCase().includes(category.toLowerCase())
            );
        }
        
        // Filter by active status
        if (isActive !== undefined) {
            const isActiveBoolean = isActive.toLowerCase() === 'true';
            filteredVendors = filteredVendors.filter(vendor => 
                vendor.isActive === isActiveBoolean
            );
        }
        
        // Filter by city
        if (city) {
            filteredVendors = filteredVendors.filter(vendor => 
                vendor.address.city.toLowerCase().includes(city.toLowerCase())
            );
        }
        
        // Filter by state
        if (state) {
            filteredVendors = filteredVendors.filter(vendor => 
                vendor.address.state.toLowerCase().includes(state.toLowerCase())
            );
        }
        
        // Pagination
        const startIndex = (parseInt(page) - 1) * parseInt(limit);
        const endIndex = startIndex + parseInt(limit);
        const paginatedVendors = filteredVendors.slice(startIndex, endIndex);
        
        res.status(200).json({
            success: true,
            data: {
                vendors: paginatedVendors,
                pagination: {
                    currentPage: parseInt(page),
                    totalItems: filteredVendors.length,
                    totalPages: Math.ceil(filteredVendors.length / parseInt(limit)),
                    itemsPerPage: parseInt(limit)
                }
            },
            message: 'Vendors retrieved successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to retrieve vendors',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// GET vendor by ID
const getVendorById = (req, res) => {
    try {
        const vendorId = parseInt(req.params.id);
        const vendors = readVendorsFromFile();
        
        const vendor = vendors.find(v => v.id === vendorId);
        
        if (!vendor) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Vendor with ID ${vendorId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        res.status(200).json({
            success: true,
            data: { vendor },
            message: 'Vendor retrieved successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to retrieve vendor',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// POST - Create new vendor
const createVendor = (req, res) => {
    try {
        const vendors = readVendorsFromFile();
        const { 
            name, 
            email, 
            phone, 
            address, 
            category, 
            website, 
            establishedYear, 
            rating = 0, 
            isActive = true 
        } = req.body;
        
        // Check if vendor with same email already exists
        const existingVendor = vendors.find(v => v.email.toLowerCase() === email.toLowerCase());
        if (existingVendor) {
            return res.status(400).json({
                success: false,
                error: {
                    message: 'Vendor with this email already exists',
                    status: 400,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        const newVendor = {
            id: generateNewId(vendors),
            name: name.trim(),
            email: email.trim().toLowerCase(),
            phone: phone.trim(),
            address: {
                street: address.street.trim(),
                city: address.city.trim(),
                state: address.state.trim(),
                zipCode: address.zipCode.trim(),
                country: address.country.trim()
            },
            category: category.trim(),
            website: website ? website.trim() : null,
            establishedYear: establishedYear ? parseInt(establishedYear) : null,
            rating: parseFloat(rating),
            isActive: Boolean(isActive),
            createdAt: new Date().toISOString()
        };
        
        vendors.push(newVendor);
        
        if (writeVendorsToFile(vendors)) {
            res.status(201).json({
                success: true,
                data: { vendor: newVendor },
                message: 'Vendor created successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save vendor to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to create vendor',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// PUT - Update entire vendor
const updateVendor = (req, res) => {
    try {
        const vendorId = parseInt(req.params.id);
        const vendors = readVendorsFromFile();
        const { 
            name, 
            email, 
            phone, 
            address, 
            category, 
            website, 
            establishedYear, 
            rating, 
            isActive 
        } = req.body;
        
        const vendorIndex = vendors.findIndex(v => v.id === vendorId);
        
        if (vendorIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Vendor with ID ${vendorId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        // Check if email is already used by another vendor
        const existingVendor = vendors.find(v => 
            v.id !== vendorId && v.email.toLowerCase() === email.toLowerCase()
        );
        if (existingVendor) {
            return res.status(400).json({
                success: false,
                error: {
                    message: 'Email is already used by another vendor',
                    status: 400,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        // Keep original creation date and ID
        const originalVendor = vendors[vendorIndex];
        const updatedVendor = {
            id: vendorId,
            name: name.trim(),
            email: email.trim().toLowerCase(),
            phone: phone.trim(),
            address: {
                street: address.street.trim(),
                city: address.city.trim(),
                state: address.state.trim(),
                zipCode: address.zipCode.trim(),
                country: address.country.trim()
            },
            category: category.trim(),
            website: website ? website.trim() : null,
            establishedYear: establishedYear ? parseInt(establishedYear) : null,
            rating: parseFloat(rating),
            isActive: Boolean(isActive),
            createdAt: originalVendor.createdAt,
            updatedAt: new Date().toISOString()
        };
        
        vendors[vendorIndex] = updatedVendor;
        
        if (writeVendorsToFile(vendors)) {
            res.status(200).json({
                success: true,
                data: { vendor: updatedVendor },
                message: 'Vendor updated successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated vendor to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to update vendor',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// PATCH - Partially update vendor
const patchVendor = (req, res) => {
    try {
        const vendorId = parseInt(req.params.id);
        const vendors = readVendorsFromFile();
        
        const vendorIndex = vendors.findIndex(v => v.id === vendorId);
        
        if (vendorIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Vendor with ID ${vendorId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        const existingVendor = vendors[vendorIndex];
        const updates = req.body;
        
        // Validate and apply updates
        const updatedVendor = { ...existingVendor };
        
        if (updates.name !== undefined) {
            if (!updates.name || typeof updates.name !== 'string' || updates.name.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Vendor name must be a non-empty string',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedVendor.name = updates.name.trim();
        }
        
        if (updates.email !== undefined) {
            if (!updates.email || typeof updates.email !== 'string' || !isValidEmail(updates.email)) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Valid email address is required',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            
            // Check if email is already used by another vendor
            const existingVendorWithEmail = vendors.find(v => 
                v.id !== vendorId && v.email.toLowerCase() === updates.email.toLowerCase()
            );
            if (existingVendorWithEmail) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Email is already used by another vendor',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            
            updatedVendor.email = updates.email.trim().toLowerCase();
        }
        
        if (updates.phone !== undefined) {
            if (!updates.phone || typeof updates.phone !== 'string' || updates.phone.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Phone number is required',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedVendor.phone = updates.phone.trim();
        }
        
        if (updates.category !== undefined) {
            if (!updates.category || typeof updates.category !== 'string' || updates.category.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Vendor category must be a non-empty string',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedVendor.category = updates.category.trim();
        }
        
        if (updates.address !== undefined) {
            if (!updates.address || typeof updates.address !== 'object') {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Address must be an object',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            
            updatedVendor.address = { ...updatedVendor.address };
            
            if (updates.address.street !== undefined) {
                if (!updates.address.street || typeof updates.address.street !== 'string') {
                    return res.status(400).json({
                        success: false,
                        error: {
                            message: 'Street address is required',
                            status: 400,
                            timestamp: new Date().toISOString()
                        }
                    });
                }
                updatedVendor.address.street = updates.address.street.trim();
            }
            
            if (updates.address.city !== undefined) {
                if (!updates.address.city || typeof updates.address.city !== 'string') {
                    return res.status(400).json({
                        success: false,
                        error: {
                            message: 'City is required',
                            status: 400,
                            timestamp: new Date().toISOString()
                        }
                    });
                }
                updatedVendor.address.city = updates.address.city.trim();
            }
            
            if (updates.address.state !== undefined) {
                if (!updates.address.state || typeof updates.address.state !== 'string') {
                    return res.status(400).json({
                        success: false,
                        error: {
                            message: 'State is required',
                            status: 400,
                            timestamp: new Date().toISOString()
                        }
                    });
                }
                updatedVendor.address.state = updates.address.state.trim();
            }
            
            if (updates.address.zipCode !== undefined) {
                if (!updates.address.zipCode || typeof updates.address.zipCode !== 'string') {
                    return res.status(400).json({
                        success: false,
                        error: {
                            message: 'Zip code is required',
                            status: 400,
                            timestamp: new Date().toISOString()
                        }
                    });
                }
                updatedVendor.address.zipCode = updates.address.zipCode.trim();
            }
            
            if (updates.address.country !== undefined) {
                if (!updates.address.country || typeof updates.address.country !== 'string') {
                    return res.status(400).json({
                        success: false,
                        error: {
                            message: 'Country is required',
                            status: 400,
                            timestamp: new Date().toISOString()
                        }
                    });
                }
                updatedVendor.address.country = updates.address.country.trim();
            }
        }
        
        if (updates.website !== undefined) {
            updatedVendor.website = updates.website ? updates.website.trim() : null;
        }
        
        if (updates.establishedYear !== undefined) {
            updatedVendor.establishedYear = updates.establishedYear ? parseInt(updates.establishedYear) : null;
        }
        
        if (updates.rating !== undefined) {
            if (typeof updates.rating !== 'number' || updates.rating < 0 || updates.rating > 5) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Rating must be a number between 0 and 5',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedVendor.rating = parseFloat(updates.rating);
        }
        
        if (updates.isActive !== undefined) {
            updatedVendor.isActive = Boolean(updates.isActive);
        }
        
        updatedVendor.updatedAt = new Date().toISOString();
        
        vendors[vendorIndex] = updatedVendor;
        
        if (writeVendorsToFile(vendors)) {
            res.status(200).json({
                success: true,
                data: { vendor: updatedVendor },
                message: 'Vendor updated successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated vendor to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to update vendor',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// DELETE vendor
const deleteVendor = (req, res) => {
    try {
        const vendorId = parseInt(req.params.id);
        const vendors = readVendorsFromFile();
        
        const vendorIndex = vendors.findIndex(v => v.id === vendorId);
        
        if (vendorIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Vendor with ID ${vendorId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        const deletedVendor = vendors[vendorIndex];
        vendors.splice(vendorIndex, 1);
        
        if (writeVendorsToFile(vendors)) {
            res.status(200).json({
                success: true,
                data: { deletedVendor },
                message: 'Vendor deleted successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated vendors to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to delete vendor',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

module.exports = {
    getAllVendors,
    getVendorById,
    createVendor,
    updateVendor,
    patchVendor,
    deleteVendor
};