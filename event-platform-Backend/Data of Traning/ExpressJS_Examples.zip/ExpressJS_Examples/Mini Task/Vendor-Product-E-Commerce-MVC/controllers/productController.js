// Product Controller
const fs = require('fs');
const path = require('path');

// Path to products data file
const productsFilePath = path.join(__dirname, '../data/products.json');

// Helper function to read products from file
const readProductsFromFile = () => {
    try {
        const data = fs.readFileSync(productsFilePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading products file:', error);
        return [];
    }
};

// Helper function to write products to file
const writeProductsToFile = (products) => {
    try {
        fs.writeFileSync(productsFilePath, JSON.stringify(products, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing products file:', error);
        return false;
    }
};

// Helper function to generate new ID
const generateNewId = (products) => {
    return products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
};

// GET all products
const getAllProducts = (req, res) => {
    try {
        const products = readProductsFromFile();
        
        // Handle query parameters for filtering and pagination
        const { category, vendorId, minPrice, maxPrice, page = 1, limit = 10 } = req.query;
        
        let filteredProducts = products;
        
        // Filter by category
        if (category) {
            filteredProducts = filteredProducts.filter(product => 
                product.category.toLowerCase().includes(category.toLowerCase())
            );
        }
        
        // Filter by vendor ID
        if (vendorId) {
            filteredProducts = filteredProducts.filter(product => 
                product.vendorId === parseInt(vendorId)
            );
        }
        
        // Filter by price range
        if (minPrice) {
            filteredProducts = filteredProducts.filter(product => 
                product.price >= parseFloat(minPrice)
            );
        }
        
        if (maxPrice) {
            filteredProducts = filteredProducts.filter(product => 
                product.price <= parseFloat(maxPrice)
            );
        }
        
        // Pagination
        const startIndex = (parseInt(page) - 1) * parseInt(limit);
        const endIndex = startIndex + parseInt(limit);
        const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
        
        res.status(200).json({
            success: true,
            data: {
                products: paginatedProducts,
                pagination: {
                    currentPage: parseInt(page),
                    totalItems: filteredProducts.length,
                    totalPages: Math.ceil(filteredProducts.length / parseInt(limit)),
                    itemsPerPage: parseInt(limit)
                }
            },
            message: 'Products retrieved successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to retrieve products',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// GET product by ID
const getProductById = (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const products = readProductsFromFile();
        
        const product = products.find(p => p.id === productId);
        
        if (!product) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Product with ID ${productId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        res.status(200).json({
            success: true,
            data: { product },
            message: 'Product retrieved successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to retrieve product',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// POST - Create new product
const createProduct = (req, res) => {
    try {
        const products = readProductsFromFile();
        const { name, description, price, category, vendorId, stock } = req.body;
        
        const newProduct = {
            id: generateNewId(products),
            name: name.trim(),
            description: description.trim(),
            price: parseFloat(price),
            category: category.trim(),
            vendorId: parseInt(vendorId),
            stock: parseInt(stock),
            createdAt: new Date().toISOString()
        };
        
        products.push(newProduct);
        
        if (writeProductsToFile(products)) {
            res.status(201).json({
                success: true,
                data: { product: newProduct },
                message: 'Product created successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save product to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to create product',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// PUT - Update entire product
const updateProduct = (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const products = readProductsFromFile();
        const { name, description, price, category, vendorId, stock } = req.body;
        
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Product with ID ${productId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        // Keep original creation date and ID
        const originalProduct = products[productIndex];
        const updatedProduct = {
            id: productId,
            name: name.trim(),
            description: description.trim(),
            price: parseFloat(price),
            category: category.trim(),
            vendorId: parseInt(vendorId),
            stock: parseInt(stock),
            createdAt: originalProduct.createdAt,
            updatedAt: new Date().toISOString()
        };
        
        products[productIndex] = updatedProduct;
        
        if (writeProductsToFile(products)) {
            res.status(200).json({
                success: true,
                data: { product: updatedProduct },
                message: 'Product updated successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated product to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to update product',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// PATCH - Partially update product
const patchProduct = (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const products = readProductsFromFile();
        
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Product with ID ${productId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        const existingProduct = products[productIndex];
        const updates = req.body;
        
        // Validate and apply updates
        const updatedProduct = { ...existingProduct };
        
        if (updates.name !== undefined) {
            if (!updates.name || typeof updates.name !== 'string' || updates.name.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Product name must be a non-empty string',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.name = updates.name.trim();
        }
        
        if (updates.description !== undefined) {
            if (!updates.description || typeof updates.description !== 'string' || updates.description.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Product description must be a non-empty string',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.description = updates.description.trim();
        }
        
        if (updates.price !== undefined) {
            if (typeof updates.price !== 'number' || updates.price <= 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Product price must be a positive number',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.price = parseFloat(updates.price);
        }
        
        if (updates.category !== undefined) {
            if (!updates.category || typeof updates.category !== 'string' || updates.category.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Product category must be a non-empty string',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.category = updates.category.trim();
        }
        
        if (updates.vendorId !== undefined) {
            if (typeof updates.vendorId !== 'number' || updates.vendorId <= 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Vendor ID must be a positive number',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.vendorId = parseInt(updates.vendorId);
        }
        
        if (updates.stock !== undefined) {
            if (typeof updates.stock !== 'number' || updates.stock < 0) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'Product stock must be a non-negative number',
                        status: 400,
                        timestamp: new Date().toISOString()
                    }
                });
            }
            updatedProduct.stock = parseInt(updates.stock);
        }
        
        updatedProduct.updatedAt = new Date().toISOString();
        
        products[productIndex] = updatedProduct;
        
        if (writeProductsToFile(products)) {
            res.status(200).json({
                success: true,
                data: { product: updatedProduct },
                message: 'Product updated successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated product to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to update product',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

// DELETE product
const deleteProduct = (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const products = readProductsFromFile();
        
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({
                success: false,
                error: {
                    message: `Product with ID ${productId} not found`,
                    status: 404,
                    timestamp: new Date().toISOString()
                }
            });
        }
        
        const deletedProduct = products[productIndex];
        products.splice(productIndex, 1);
        
        if (writeProductsToFile(products)) {
            res.status(200).json({
                success: true,
                data: { deletedProduct },
                message: 'Product deleted successfully',
                timestamp: new Date().toISOString()
            });
        } else {
            throw new Error('Failed to save updated products to file');
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: {
                message: 'Failed to delete product',
                details: error.message,
                status: 500,
                timestamp: new Date().toISOString()
            }
        });
    }
};

module.exports = {
    getAllProducts,
    getProductById,
    createProduct,
    updateProduct,
    patchProduct,
    deleteProduct
};