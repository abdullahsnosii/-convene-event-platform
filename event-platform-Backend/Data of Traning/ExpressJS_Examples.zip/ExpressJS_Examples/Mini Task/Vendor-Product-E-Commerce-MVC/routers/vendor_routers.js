// Vendor Routes
const express = require('express');
const router = express.Router();

// Import vendor controller
const {
    getAllVendors,
    getVendorById,
    createVendor,
    updateVendor,
    patchVendor,
    deleteVendor
} = require('../controllers/vendorController');

// Import middlewares
const { validateVendor } = require('../middlewares/middlewares');

// Routes for vendors

// GET /api/vendors - Get all vendors with optional filtering and pagination
// Query parameters: category, isActive, city, state, page, limit
router.get('/', getAllVendors);

// GET /api/vendors/:id - Get a specific vendor by ID
router.get('/:id', getVendorById);

// POST /api/vendors - Create a new vendor
// Requires: name, email, phone, address, category
// Optional: website, establishedYear, rating, isActive
router.post('/', validateVendor, createVendor);

// PUT /api/vendors/:id - Update entire vendor
// Requires: name, email, phone, address, category, website, establishedYear, rating, isActive
router.put('/:id', validateVendor, updateVendor);

// PATCH /api/vendors/:id - Partially update vendor
// Optional: name, email, phone, address, category, website, establishedYear, rating, isActive
router.patch('/:id', patchVendor);

// DELETE /api/vendors/:id - Delete a vendor
router.delete('/:id', deleteVendor);

module.exports = router;