// Product Routes
const express = require('express');
const router = express.Router();

// Import product controller
const {
    getAllProducts,
    getProductById,
    createProduct,
    updateProduct,
    patchProduct,
    deleteProduct
} = require('../controllers/productController');

// Import middlewares
const { validateProduct } = require('../middlewares/middlewares');

// Routes for products

// GET /api/products - Get all products with optional filtering and pagination
// Query parameters: category, vendorId, minPrice, maxPrice, page, limit
router.get('/', getAllProducts);

// GET /api/products/:id - Get a specific product by ID
router.get('/:id', getProductById);

// POST /api/products - Create a new product
// Requires: name, description, price, category, vendorId, stock
router.post('/', validateProduct, createProduct);

// PUT /api/products/:id - Update entire product
// Requires: name, description, price, category, vendorId, stock
router.put('/:id', validateProduct, updateProduct);

// PATCH /api/products/:id - Partially update product
// Optional: name, description, price, category, vendorId, stock
router.patch('/:id', patchProduct);

// DELETE /api/products/:id - Delete a product
router.delete('/:id', deleteProduct);

module.exports = router;