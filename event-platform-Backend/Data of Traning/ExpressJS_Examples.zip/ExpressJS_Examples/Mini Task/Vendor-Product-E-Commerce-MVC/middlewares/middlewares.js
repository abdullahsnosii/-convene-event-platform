// Middleware functions for the e-commerce application

// Logging middleware
const requestLogger = (req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url} - IP: ${req.ip}`);
    next();
};

// Error handling middleware
const errorHandler = (err, req, res, next) => {
    console.error('Error occurred:', err.message);
    
    // Set default error status and message
    let status = err.status || 500;
    let message = err.message || 'Internal Server Error';
    
    // Handle specific error types
    if (err.name === 'ValidationError') {
        status = 400;
        message = 'Validation Error: ' + err.message;
    } else if (err.name === 'CastError') {
        status = 400;
        message = 'Invalid ID format';
    }
    
    res.status(status).json({
        success: false,
        error: {
            message: message,
            status: status,
            timestamp: new Date().toISOString()
        }
    });
};

// Not found middleware
const notFound = (req, res) => {
    res.status(404).json({
        success: false,
        error: {
            message: `Route ${req.method} ${req.url} not found`,
            status: 404,
            timestamp: new Date().toISOString()
        }
    });
};

// Validation middleware for product data
const validateProduct = (req, res, next) => {
    const { name, description, price, category, vendorId, stock } = req.body;
    
    const errors = [];
    
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
        errors.push('Product name is required and must be a non-empty string');
    }
    
    if (!description || typeof description !== 'string' || description.trim().length === 0) {
        errors.push('Product description is required and must be a non-empty string');
    }
    
    if (price === undefined || price === null || typeof price !== 'number' || price <= 0) {
        errors.push('Product price is required and must be a positive number');
    }
    
    if (!category || typeof category !== 'string' || category.trim().length === 0) {
        errors.push('Product category is required and must be a non-empty string');
    }
    
    if (vendorId === undefined || vendorId === null || typeof vendorId !== 'number' || vendorId <= 0) {
        errors.push('Vendor ID is required and must be a positive number');
    }
    
    if (stock === undefined || stock === null || typeof stock !== 'number' || stock < 0) {
        errors.push('Product stock is required and must be a non-negative number');
    }
    
    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            error: {
                message: 'Validation failed',
                details: errors,
                status: 400,
                timestamp: new Date().toISOString()
            }
        });
    }
    
    next();
};

// Validation middleware for vendor data
const validateVendor = (req, res, next) => {
    const { name, email, phone, address, category } = req.body;
    
    const errors = [];
    
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
        errors.push('Vendor name is required and must be a non-empty string');
    }
    
    if (!email || typeof email !== 'string' || !isValidEmail(email)) {
        errors.push('Valid email address is required');
    }
    
    if (!phone || typeof phone !== 'string' || phone.trim().length === 0) {
        errors.push('Phone number is required');
    }
    
    if (!category || typeof category !== 'string' || category.trim().length === 0) {
        errors.push('Vendor category is required and must be a non-empty string');
    }
    
    if (!address || typeof address !== 'object') {
        errors.push('Address is required and must be an object');
    } else {
        if (!address.street || typeof address.street !== 'string') {
            errors.push('Street address is required');
        }
        if (!address.city || typeof address.city !== 'string') {
            errors.push('City is required');
        }
        if (!address.state || typeof address.state !== 'string') {
            errors.push('State is required');
        }
        if (!address.zipCode || typeof address.zipCode !== 'string') {
            errors.push('Zip code is required');
        }
        if (!address.country || typeof address.country !== 'string') {
            errors.push('Country is required');
        }
    }
    
    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            error: {
                message: 'Validation failed',
                details: errors,
                status: 400,
                timestamp: new Date().toISOString()
            }
        });
    }
    
    next();
};

// Helper function to validate email format
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

module.exports = {
    requestLogger,
    errorHandler,
    notFound,
    validateProduct,
    validateVendor
};