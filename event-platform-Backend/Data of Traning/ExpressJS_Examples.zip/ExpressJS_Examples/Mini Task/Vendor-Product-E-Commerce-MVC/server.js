// E-Commerce API Server
const express = require('express');
const morgan = require('morgan');

// Import middlewares
const {
    requestLogger,
    errorHandler,
    notFound,
    corsMiddleware,
    rateLimiter
} = require('./middlewares/middlewares');

// Import routers
const productRoutes = require('./routers/product_routers');
const vendorRoutes = require('./routers/vendor_routers');

// Create Express application
const app = express();

// Configuration
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';

// Global middlewares
app.use(morgan('combined')); // HTTP request logger
app.use(requestLogger); // Custom request logger


// API Routes
app.use('/api/products', productRoutes);
app.use('/api/vendors', vendorRoutes);

// API status endpoint
app.get('/api', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'E-Commerce API is running',
        version: '1.0.0',
        endpoints: {
            products: '/api/products',
            vendors: '/api/vendors',
            documentation: '/'
        },
        timestamp: new Date().toISOString()
    });
});

// Handle 404 - Route not found
app.use(notFound);

// Global error handler (must be last)
app.use(errorHandler);

// Start server
app.listen(PORT, HOST, () => {
    console.log('='.repeat(60));
    console.log('🚀 E-COMMERCE API SERVER STARTED SUCCESSFULLY');
    console.log('='.repeat(60));
    console.log(`📍 Server URL: http://${HOST}:${PORT}`);
    console.log(`🏥 Health Check: http://${HOST}:${PORT}/health`);
    console.log(`📚 API Documentation: http://${HOST}:${PORT}/`);
    console.log(`🛍️  Products API: http://${HOST}:${PORT}/api/products`);
    console.log(`🏢 Vendors API: http://${HOST}:${PORT}/api/vendors`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`⏰ Started at: ${new Date().toISOString()}`);
    console.log('='.repeat(60));
    console.log('Available endpoints:');
    console.log('  GET    /              - API documentation');
    console.log('  GET    /health        - Health check');
    console.log('  GET    /api           - API status');
    console.log('  GET    /api/products  - Get all products');
    console.log('  POST   /api/products  - Create product');
    console.log('  GET    /api/products/:id - Get product by ID');
    console.log('  PUT    /api/products/:id - Update product');
    console.log('  PATCH  /api/products/:id - Partial update product');
    console.log('  DELETE /api/products/:id - Delete product');
    console.log('  GET    /api/vendors   - Get all vendors');
    console.log('  POST   /api/vendors   - Create vendor');
    console.log('  GET    /api/vendors/:id - Get vendor by ID');
    console.log('  PUT    /api/vendors/:id - Update vendor');
    console.log('  PATCH  /api/vendors/:id - Partial update vendor');
    console.log('  DELETE /api/vendors/:id - Delete vendor');
    console.log('='.repeat(60));
});


module.exports = app;