# E-Commerce Vendor-Product API

A RESTful API for managing vendors and products in an e-commerce platform, built with Express.js following the MVC (Model-View-Controller) architecture pattern.

## 🚀 Features

- **Complete CRUD Operations** for both vendors and products
- **RESTful API Design** with proper HTTP methods (GET, POST, PUT, PATCH, DELETE)
- **MVC Architecture** for clean code organization
- **File-based Data Storage** with JSON files
- **Input Validation** with comprehensive error handling
- **Filtering and Pagination** support
- **CORS Support** for cross-origin requests
- **Rate Limiting** for API protection
- **Comprehensive Logging** for monitoring
- **API Documentation** with examples

## 📁 Project Structure

```
Vendor-Product-E-Commerce-MVC/
├── controllers/
│   ├── productController.js    # Product business logic
│   └── vendorController.js     # Vendor business logic
├── data/
│   ├── products.json          # Products data storage
│   └── vendors.json           # Vendors data storage
├── middlewares/
│   └── middlewares.js         # Custom middleware functions
├── routers/
│   ├── product_routers.js     # Product route definitions
│   └── vendor_routers.js      # Vendor route definitions
├── package.json               # Dependencies and scripts
├── README.md                  # Project documentation
└── server.js                  # Main application entry point
```

## 🛠️ Installation & Setup

1. **Clone or download the project**
2. **Navigate to the project directory**
3. **Install dependencies:**
   ```bash
   npm install
   ```

## 🏃‍♂️ Running the Application

### Development Mode (with auto-restart)
```bash
npm run dev
```

### Production Mode
```bash
npm start
```

The server will start on `http://localhost:3000` by default.
## 📋 API Endpoints

### 🏠 General Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API documentation and welcome |
| GET | `/health` | Health check endpoint |
| GET | `/api` | API status information |

### 🛍️ Product Endpoints

| Method | Endpoint | Description | Body Required |
|--------|----------|-------------|---------------|
| GET | `/api/products` | Get all products (with filtering/pagination) | ❌ |
| GET | `/api/products/:id` | Get product by ID | ❌ |
| POST | `/api/products` | Create new product | ✅ |
| PUT | `/api/products/:id` | Update entire product | ✅ |
| PATCH | `/api/products/:id` | Partially update product | ✅ |
| DELETE | `/api/products/:id` | Delete product | ❌ |

#### Product Query Parameters (GET /api/products)
- `category` - Filter by product category
- `vendorId` - Filter by vendor ID
- `minPrice` - Filter by minimum price
- `maxPrice` - Filter by maximum price
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)

#### Product Data Structure
```json
{
  "name": "Product Name",
  "description": "Product description",
  "price": 99.99,
  "category": "Electronics",
  "vendorId": 1,
  "stock": 50
}
```

### 🏢 Vendor Endpoints

| Method | Endpoint | Description | Body Required |
|--------|----------|-------------|---------------|
| GET | `/api/vendors` | Get all vendors (with filtering/pagination) | ❌ |
| GET | `/api/vendors/:id` | Get vendor by ID | ❌ |
| POST | `/api/vendors` | Create new vendor | ✅ |
| PUT | `/api/vendors/:id` | Update entire vendor | ✅ |
| PATCH | `/api/vendors/:id` | Partially update vendor | ✅ |
| DELETE | `/api/vendors/:id` | Delete vendor | ❌ |

#### Vendor Query Parameters (GET /api/vendors)
- `category` - Filter by vendor category
- `isActive` - Filter by active status (true/false)
- `city` - Filter by city
- `state` - Filter by state
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)

#### Vendor Data Structure
```json
{
  "name": "Vendor Name",
  "email": "vendor@example.com",
  "phone": "+1-555-0123",
  "address": {
    "street": "123 Main St",
    "city": "Anytown",
    "state": "CA",
    "zipCode": "12345",
    "country": "USA"
  },
  "category": "Technology",
  "website": "https://example.com",
  "establishedYear": 2020,
  "rating": 4.5,
  "isActive": true
}
```

## 📝 Usage Examples

### 1. Get All Products
```bash
curl -X GET "http://localhost:3000/api/products"
```

### 2. Get Products with Filtering
```bash
curl -X GET "http://localhost:3000/api/products?category=Electronics&minPrice=100&page=1&limit=5"
```

### 3. Create a New Product
```bash
curl -X POST "http://localhost:3000/api/products" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Gaming Mouse",
    "description": "High-precision gaming mouse with RGB lighting",
    "price": 79.99,
    "category": "Electronics",
    "vendorId": 1,
    "stock": 30
  }'
```

### 4. Update a Product (PUT)
```bash
curl -X PUT "http://localhost:3000/api/products/1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated Gaming Mouse",
    "description": "Updated description",
    "price": 89.99,
    "category": "Gaming",
    "vendorId": 1,
    "stock": 25
  }'
```

### 5. Partially Update a Product (PATCH)
```bash
curl -X PATCH "http://localhost:3000/api/products/1" \
  -H "Content-Type: application/json" \
  -d '{
    "price": 69.99,
    "stock": 35
  }'
```

### 6. Delete a Product
```bash
curl -X DELETE "http://localhost:3000/api/products/1"
```

### 7. Create a New Vendor
```bash
curl -X POST "http://localhost:3000/api/vendors" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tech Solutions Inc",
    "email": "contact@techsolutions.com",
    "phone": "+1-555-0199",
    "address": {
      "street": "456 Tech Street",
      "city": "Silicon Valley",
      "state": "CA",
      "zipCode": "94000",
      "country": "USA"
    },
    "category": "Technology",
    "website": "https://techsolutions.com",
    "establishedYear": 2018,
    "rating": 4.7,
    "isActive": true
  }'
```

## 🔧 API Response Format

All API responses follow a consistent format:

### Success Response
```json
{
  "success": true,
  "data": {
    // Response data here
  },
  "message": "Operation completed successfully",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "message": "Error description",
    "status": 400,
    "timestamp": "2024-01-15T10:30:00.000Z"
  }
}
```

### Paginated Response
```json
{
  "success": true,
  "data": {
    "products": [...],
    "pagination": {
      "currentPage": 1,
      "totalItems": 25,
      "totalPages": 3,
      "itemsPerPage": 10
    }
  },
  "message": "Products retrieved successfully",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## 🔒 Security Features

- **CORS Support** - Cross-origin resource sharing enabled
- **Rate Limiting** - Prevents API abuse (100 requests per 15 minutes per IP)
- **Input Validation** - Comprehensive data validation
- **Error Handling** - Secure error responses without sensitive information

## 🚨 Error Handling

The API includes comprehensive error handling for:

- **Validation Errors** (400) - Invalid input data
- **Not Found Errors** (404) - Resource not found
- **Server Errors** (500) - Internal server errors
- **Rate Limit Errors** (429) - Too many requests

## 📊 Data Validation

### Product Validation
- `name`: Required, non-empty string
- `description`: Required, non-empty string
- `price`: Required, positive number
- `category`: Required, non-empty string
- `vendorId`: Required, positive number
- `stock`: Required, non-negative number

### Vendor Validation
- `name`: Required, non-empty string
- `email`: Required, valid email format
- `phone`: Required, non-empty string
- `address`: Required object with street, city, state, zipCode, country
- `category`: Required, non-empty string
- `website`: Optional, string
- `establishedYear`: Optional, number
- `rating`: Optional, number between 0 and 5
- `isActive`: Optional, boolean

## 🔍 Monitoring & Logging

The application includes:
- **HTTP Request Logging** using Morgan
- **Custom Request Logger** with timestamps
- **Error Logging** with detailed error information
- **Health Check Endpoint** for monitoring

## 🚀 Deployment

For production deployment:

1. Set environment variables:
   ```bash
   export NODE_ENV=production
   export PORT=3000
   export HOST=0.0.0.0
   ```

2. Start the application:
   ```bash
   npm start
   ```

## 🤝 Contributing

1. Follow the MVC architecture pattern
2. Add proper input validation
3. Include error handling
4. Write clear documentation
5. Test all endpoints thoroughly

## 📄 License

MIT License - feel free to use this project for learning and development purposes.

---

**Happy Coding! 🎉**

1. Make changes to the appropriate controller, middleware, or router files
2. Test your changes using the API endpoints
3. Ensure proper error handling and validation
4. Update documentation if needed

## License

MIT License