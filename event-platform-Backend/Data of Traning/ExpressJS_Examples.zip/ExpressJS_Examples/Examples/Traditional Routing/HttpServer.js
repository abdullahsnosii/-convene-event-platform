const http = require('http');
const fs = require('fs');

data = fs.readFileSync(`${__dirname}/students.json`, 'utf8');
const students = JSON.parse(data);

const server = http.createServer((req, res) => {

    if(req.method === 'GET' && req.url === '/api/students') {
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(students));
    }
    else if(req.method === 'POST' && req.url === '/api/students') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const newStudent = JSON.parse(body);
            newStudent.id = students.length + 1; // Simulate ID assignment
            students.push(newStudent);
            fs.writeFileSync(`${__dirname}/students.json`, JSON.stringify(students, null, 2));
            res.writeHead(201, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(newStudent));
        });
    }

})


server.listen(3000, () => {
  console.log('Server running at http://localhost:3000/');
});
