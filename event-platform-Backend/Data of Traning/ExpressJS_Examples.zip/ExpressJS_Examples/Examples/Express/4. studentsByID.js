const express = require('express');
const fs = require('fs');
const path = require('path');

data = fs.readFileSync(path.join(__dirname, 'students.json'), 'utf8');
const students = JSON.parse(data);

const app = express();
app.use(express.json());

app.get('/api/students/:id', (req, res) => {
    console.log(req)
    const studentId = req.params.id * 1; // Convert to number
    const student = students.find(s => s.id === studentId);
    if (student) {
        res.status(200).json(student);
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
})

// patch
app.patch(
    '/api/students/:id',
    (req, res) => {
        const studentId = req.params.id * 1; // Convert to number
        const studentIndex = students.findIndex(s => s.id === studentId);
        if (studentIndex !== -1) {
            const updatedStudent = { ...students[studentIndex], ...req.body };
            students[studentIndex] = updatedStudent;
            fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));
            res.status(200).json(updatedStudent);
        } else {
            res.status(404).json({ message: 'Student not found' });
        }
    }
)

// delete
app.delete(
    '/api/students/:id',
    (req, res) => {
        const studentId = req.params.id * 1; // Convert to number
        const studentIndex = students.findIndex(s => s.id === studentId);
        if (studentIndex !== -1) {
            students.splice(studentIndex, 1);
            fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));
            res.status(204).send(); // No content
        }
        else {
            res.status(404).json({ message: 'Student not found' });
        }
    }
);

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000/')
});