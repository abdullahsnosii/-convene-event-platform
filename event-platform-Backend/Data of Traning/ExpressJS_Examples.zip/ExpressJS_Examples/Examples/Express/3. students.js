const express = require('express');
const fs = require('fs');
const path = require('path');

data = fs.readFileSync(path.join(__dirname, 'students.json'), 'utf8');
const students = JSON.parse(data);

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
    res
    .status(200)
    .json({ message: 'Welcome to the Students API' , app: 'Students API'})
})

app.get('/api/students', (req, res) => {
    res
    .status(200)
    .json({
        status: 'success', 
        results: students.length,
        data: { 
            students 
            // students: students
        }
    });
})

app.post('/api/students', (req, res) => {
    const newStudent = req.body;
    newStudent.id = students.length + 1; // Simulate ID assignment
    students.push(newStudent);
    fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));
    res.status(201).json(newStudent);
});

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000/')
});