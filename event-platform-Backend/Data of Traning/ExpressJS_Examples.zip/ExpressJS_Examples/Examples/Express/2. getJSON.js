const express = require('express');

const app = express()

app.get('/', (req, res) => {
    res
    .status(200)
    .json({ message: 'Hello World from ExpressJS' , app: 'Students API'})
})

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000/')
});
