const express = require('express');
const fs = require('fs');
const path = require('path');

data = fs.readFileSync(path.join(__dirname, 'students.json'), 'utf8');
const students = JSON.parse(data);

const app = express();
app.use(express.json());

const getByID = (req, res) => {
    const studentId = req.params.id * 1; // Convert to number
    const student = students.find(s => s.id === studentId);
    if (student) {
        res.status(200).json(student);
    }
    else {
        res.status(404).json({ message: 'Student not found' });
    }
}

const postByID = (req, res) => {
    const studentId = Number(req.params.id);

    if (students.find(s => s.id === studentId)) {
        return res.status(409).json({ message: 'Student with that ID already exists' });
    }

    const { name, age, major } = req.body;
    if (!name || !age || !major) {
        return res.status(400).json({ message: 'Missing required student fields' });
    }

    const newStudent = { id: studentId, name, age, major };
    students.push(newStudent);
    fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));

    res.status(201).json(newStudent);
}

const deleteByID = (req, res) => {
    const studentId = Number(req.params.id);
    const idx = students.findIndex(s => s.id === studentId);
    if (idx === -1) {
        return res.status(404).json({ message: 'Student not found' });
    }

    const removed = students.splice(idx, 1)[0];
    fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));

    res.status(200).json(removed);
}   

const putByID = (req, res) => {
    const studentId = Number(req.params.id);
    
    if (!req.body.name || !req.body.age || !req.body.major) {
        return res.status(400).json({ message: 'Missing required student fields' });
    }
    const student = students.find(s => s.id === studentId);

    if (!student) {
        return res.status(404).json({ message: 'Student not found' });
    }

    student.name = req.body.name;
    student.age = req.body.age;
    student.major = req.body.major;

    fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));
    res.status(200).json(student);
};

const patchByID = (req, res) => {
    const studentId = Number(req.params.id);
    const student = students.find(s => s.id === studentId);

    if (!student) {
        return res.status(404).json({ message: 'Student not found' });
    }

    const { name, age, major } = req.body;
    if (name !== undefined) student.name = name;
    if (age !== undefined) student.age = age;
    if (major !== undefined) student.major = major;

    fs.writeFileSync(path.join(__dirname, 'students.json'), JSON.stringify(students, null, 2));

    res.status(200).json(student);
};

app.get('/api/students/:id', getByID);
app.post('/api/students/:id', postByID);
app.delete('/api/students/:id', deleteByID);
app.put('/api/students/:id', putByID);
app.patch('/api/students/:id', patchByID);

app.route('/api/students/:id')
    .get(getByID)
    .post(postByID)
    .delete(deleteByID)
    .put(putByID)
    .patch(patchByID);

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000/')
});