const express = require('express');
const morgan = require('morgan');

// Import routers
const studentRouter = require('./routers/students_routers');
const staffRouter = require('./routers/staff_routers');

// Import middlewares
const middlewares = require('./middlewares/middlewares');

const app = express();

// Global Middlewares
// Development logging
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}

// Body parser middleware
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Custom middlewares
app.use(middlewares.logger);
app.use(middlewares.addRequestTime);

// API Routes
app.use('/api/v1/students', studentRouter);
app.use('/api/v1/staff', staffRouter);

// Health check route
app.get('/api/v1/health', (req, res) => {
    res.status(200).json({
        status: 'success',
        message: 'API is running!',
        timestamp: req.requestTime
    });
});

// Root route
app.get('/', (req, res) => {
    res.status(200).json({
        message: 'Welcome to the University Management API!',
        endpoints: {
            students: '/api/v1/students',
            staff: '/api/v1/staff',
            health: '/api/v1/health'
        }
    });
});

const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`🚀 Server running on http://localhost:${port}`);
    console.log(`📚 Students API: http://localhost:${port}/api/v1/students`);
    console.log(`👥 Staff API: http://localhost:${port}/api/v1/staff`);
    console.log(`❤️  Health Check: http://localhost:${port}/api/v1/health`);
});