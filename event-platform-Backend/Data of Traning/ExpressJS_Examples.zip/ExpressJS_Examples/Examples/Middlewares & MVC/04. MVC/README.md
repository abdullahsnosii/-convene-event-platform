# University Management API

A RESTful API built with Express.js using MVC (Model-View-Controller) architecture for managing university students and staff.

## Project Structure

```
8. MVC/
├── controllers/
│   ├── controller.js          # Legacy controller (backward compatibility)
│   ├── studentController.js   # Student operations controller
│   └── staffController.js     # Staff operations controller
├── data/
│   ├── students.json         # Student data storage
│   └── staffs.json          # Staff data storage
├── middlewares/
│   └── middlewares.js       # Custom middleware functions
├── routers/
│   ├── students_routers.js  # Student routes
│   └── staff_routers.js     # Staff routes
├── server.js                # Main application entry point
├── package.json            # Project dependencies and scripts
└── README.md              # Project documentation
```

## Features

- **MVC Architecture**: Clean separation of concerns
- **RESTful API Design**: Standard HTTP methods and status codes
- **Middleware Support**: Custom and built-in middleware
- **Error Handling**: Global error handling and validation
- **Data Persistence**: File-based JSON storage
- **Logging**: Request logging with Morgan

## Installation

1. Navigate to the project directory:
   ```bash
   cd "8. MVC"
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the server:
   ```bash
   npm start
   ```
   
   Or for development with auto-restart:
   ```bash
   npm run dev
   ```

4. The server will start on `http://localhost:3000`

## API Endpoints

### Health Check
- **GET** `/api/v1/health` - Check API status

### Students
- **GET** `/api/v1/students` - Get all students
- **POST** `/api/v1/students` - Create a new student
- **GET** `/api/v1/students/:id` - Get student by ID
- **PATCH** `/api/v1/students/:id` - Update student by ID
- **DELETE** `/api/v1/students/:id` - Delete student by ID

### Staff
- **GET** `/api/v1/staff` - Get all staff members
- **POST** `/api/v1/staff` - Create a new staff member
- **GET** `/api/v1/staff/:id` - Get staff member by ID
- **PATCH** `/api/v1/staff/:id` - Update staff member by ID
- **DELETE** `/api/v1/staff/:id` - Delete staff member by ID

## Request/Response Examples

### Get All Students
```http
GET /api/v1/students
```

**Response:**
```json
{
  "status": "success",
  "results": 5,
  "data": {
    "requestTime": "2025-10-10T12:00:00.000Z",
    "students": [
      {
        "id": 10,
        "name": "John Doe",
        "age": 20,
        "major": "Computer Science",
        "email": "john.doe@university.edu",
        "gpa": 3.5
      }
    ]
  }
}
```

### Create a Student
```http
POST /api/v1/students
Content-Type: application/json

{
  "name": "Alice Johnson",
  "age": 19,
  "major": "Biology",
  "email": "alice.johnson@university.edu",
  "gpa": 3.7
}
```

### Create a Staff Member
```http
POST /api/v1/staff
Content-Type: application/json

{
  "name": "Dr. Michael Brown",
  "position": "Professor",
  "department": "Biology",
  "email": "michael.brown@university.edu",
  "phone": "+1-555-0199",
  "office": "BIO-202"
}
```

## Middleware

The application includes several middleware functions:

- **Logger**: Logs all requests with timestamps
- **Request Time**: Adds timestamp to all requests
- **Body Validation**: Validates required fields for POST requests
- **ID Validation**: Validates ID parameters in URLs
- **Error Handling**: Global error handling for all routes

## Data Models

### Student
```json
{
  "id": "number",
  "name": "string",
  "age": "number",
  "major": "string",
  "email": "string",
  "gpa": "number"
}
```

### Staff
```json
{
  "id": "number",
  "name": "string",
  "position": "string",
  "department": "string",
  "email": "string",
  "phone": "string",
  "office": "string"
}
```

## Error Handling

The API returns consistent error responses:

```json
{
  "status": "fail|error",
  "message": "Error description"
}
```

## Status Codes

- `200` - OK (successful GET, PATCH)
- `201` - Created (successful POST)
- `204` - No Content (successful DELETE)
- `400` - Bad Request (validation errors)
- `404` - Not Found (resource not found)
- `500` - Internal Server Error (server errors)

## Dependencies

- **express**: Web framework for Node.js
- **morgan**: HTTP request logger middleware

## Development

To contribute to this project:

1. Make changes to the appropriate controller, middleware, or router files
2. Test your changes using the API endpoints
3. Ensure proper error handling and validation
4. Update documentation if needed

## License

MIT License