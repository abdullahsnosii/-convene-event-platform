const fs = require('fs');
const path = require('path');

// Read student data
const studentsData = fs.readFileSync(path.join(__dirname, '../data/students.json'), 'utf8');
const students = JSON.parse(studentsData);

// Get all students
exports.getAllStudents = (req, res) => {
    res.status(200).json({
        status: 'success',
        results: students.length,
        data: {
            requestTime: req.requestTime,
            students: students
        }
    });
};

// Create a new student
exports.createStudent = (req, res) => {
    console.log(req.body);
    const newStudent = req.body;
    newStudent.id = students.length > 0 ? Math.max(...students.map(s => s.id)) + 1 : 10;
    students.push(newStudent);
    
    fs.writeFile(path.join(__dirname, '../data/students.json'), JSON.stringify(students, null, 2), err => {
        if (err) {
            return res.status(500).json({ message: 'Failed to save student' });
        }
        res.status(201).json({
            status: 'success',
            message: 'Student created',
            requestTime: req.requestTime,
            data: {
                student: newStudent
            }
        });
    });
};

// Get student by ID
exports.getStudentById = (req, res) => {
    const studentId = req.params.id * 1; // Convert to number
    const student = students.find(s => s.id === studentId);
    
    if (student) {
        res.status(200).json({
            status: 'success',
            data: {
                student: student
            }
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Student not found' 
        });
    }
};

// Update student by ID
exports.updateStudentById = (req, res) => {
    const studentId = req.params.id * 1;
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        // Update student data
        students[studentIndex] = { ...students[studentIndex], ...req.body };
        
        fs.writeFile(path.join(__dirname, '../data/students.json'), JSON.stringify(students, null, 2), err => {
            if (err) {
                return res.status(500).json({ message: 'Failed to update student' });
            }
            res.status(200).json({
                status: 'success',
                data: {
                    student: students[studentIndex]
                }
            });
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Student not found' 
        });
    }
};

// Delete student by ID
exports.deleteStudentById = (req, res) => {
    const studentId = req.params.id * 1;
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        students.splice(studentIndex, 1);
        fs.writeFile(path.join(__dirname, '../data/students.json'), JSON.stringify(students, null, 2), err => {
            if (err) {
                return res.status(500).json({ message: 'Failed to delete student' });
            }
            res.status(204).send();
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Student not found' 
        });
    }
};