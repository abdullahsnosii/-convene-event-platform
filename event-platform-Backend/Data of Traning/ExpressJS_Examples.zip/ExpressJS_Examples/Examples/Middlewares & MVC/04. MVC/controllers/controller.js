// This file has been replaced by separate controllers
// Please use:
// - studentController.js for student-related operations
// - staffController.js for staff-related operations

// Legacy exports for backward compatibility
const studentController = require('./studentController');
const staffController = require('./staffController');

module.exports = {
    // Student operations
    getAllStudents: studentController.getAllStudents,
    createStudent: studentController.createStudent,
    getStudentById: studentController.getStudentById,
    updateStudentById: studentController.updateStudentById,
    deleteStudentById: studentController.deleteStudentById,
    
    // Staff operations
    getAllStaff: staffController.getAllStaff,
    createStaff: staffController.createStaff,
    getStaffById: staffController.getStaffById,
    updateStaffById: staffController.updateStaffById,
    deleteStaffById: staffController.deleteStaffById
};