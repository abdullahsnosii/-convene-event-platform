const fs = require('fs');
const path = require('path');

// Read staff data
const staffData = fs.readFileSync(path.join(__dirname, '../data/staffs.json'), 'utf8');
const staff = JSON.parse(staffData);

// Get all staff
exports.getAllStaff = (req, res) => {
    res.status(200).json({
        status: 'success',
        results: staff.length,
        data: {
            requestTime: req.requestTime,
            staff: staff
        }
    });
};

// Create a new staff member
exports.createStaff = (req, res) => {
    console.log(req.body);
    const newStaff = req.body;
    newStaff.id = staff.length > 0 ? Math.max(...staff.map(s => s.id)) + 1 : 1;
    staff.push(newStaff);
    
    fs.writeFile(path.join(__dirname, '../data/staffs.json'), JSON.stringify(staff, null, 2), err => {
        if (err) {
            return res.status(500).json({ message: 'Failed to save staff member' });
        }
        res.status(201).json({
            status: 'success',
            message: 'Staff member created',
            requestTime: req.requestTime,
            data: {
                staff: newStaff
            }
        });
    });
};

// Get staff by ID
exports.getStaffById = (req, res) => {
    const staffId = req.params.id * 1; // Convert to number
    const staffMember = staff.find(s => s.id === staffId);
    
    if (staffMember) {
        res.status(200).json({
            status: 'success',
            data: {
                staff: staffMember
            }
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Staff member not found' 
        });
    }
};

// Update staff by ID
exports.updateStaffById = (req, res) => {
    const staffId = req.params.id * 1;
    const staffIndex = staff.findIndex(s => s.id === staffId);
    
    if (staffIndex !== -1) {
        // Update staff data
        staff[staffIndex] = { ...staff[staffIndex], ...req.body };
        
        fs.writeFile(path.join(__dirname, '../data/staffs.json'), JSON.stringify(staff, null, 2), err => {
            if (err) {
                return res.status(500).json({ message: 'Failed to update staff member' });
            }
            res.status(200).json({
                status: 'success',
                data: {
                    staff: staff[staffIndex]
                }
            });
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Staff member not found' 
        });
    }
};

// Delete staff by ID
exports.deleteStaffById = (req, res) => {
    const staffId = req.params.id * 1;
    const staffIndex = staff.findIndex(s => s.id === staffId);
    
    if (staffIndex !== -1) {
        staff.splice(staffIndex, 1);
        fs.writeFile(path.join(__dirname, '../data/staffs.json'), JSON.stringify(staff, null, 2), err => {
            if (err) {
                return res.status(500).json({ message: 'Failed to delete staff member' });
            }
            res.status(204).send();
        });
    } else {
        res.status(404).json({ 
            status: 'fail',
            message: 'Staff member not found' 
        });
    }
};