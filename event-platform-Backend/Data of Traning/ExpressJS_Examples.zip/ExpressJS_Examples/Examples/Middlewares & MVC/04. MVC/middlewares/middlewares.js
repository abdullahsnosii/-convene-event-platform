// Middleware to log request details
exports.logger = (req, res, next) => {
    const now = new Date();
    console.log(`[${now.toISOString()}] ${req.method} ${req.originalUrl}`);
    console.log(`Hello from the middleware 👋`);
    next();
};

// Add timestamp to request
exports.addRequestTime = (req, res, next) => {
    req.requestTime = new Date().toISOString();
    next();
};

// Middleware to check student body for creation
exports.checkStudentBody = (req, res, next) => {
    if (!req.body.name || !req.body.age) {
        return res.status(400).json({ 
            status: 'fail',
            message: 'Missing name or age' 
        });
    }
    next();
};

// Middleware to check staff body for creation
exports.checkStaffBody = (req, res, next) => {
    if (!req.body.name || !req.body.position || !req.body.department) {
        return res.status(400).json({ 
            status: 'fail',
            message: 'Missing required fields: name, position, or department' 
        });
    }
    next();
};

// Middleware to validate student ID
exports.validateStudentId = (req, res, next) => {
    const studentId = req.params.id * 1;
    if (isNaN(studentId) || studentId < 0) {
        return res.status(400).json({ 
            status: 'fail',
            message: 'Invalid student ID' 
        });
    }
    next();
};

// Middleware to validate staff ID
exports.validateStaffId = (req, res, next) => {
    const staffId = req.params.id * 1;
    if (isNaN(staffId) || staffId < 0) {
        return res.status(400).json({ 
            status: 'fail',
            message: 'Invalid staff ID' 
        });
    }
    next();
};