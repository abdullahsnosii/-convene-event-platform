const express = require('express');
const studentController = require('../controllers/studentController');
const middlewares = require('../middlewares/middlewares');

const router = express.Router();

// Apply middleware to all student routes with ID parameter
router.param('id', middlewares.validateStudentId);

// Routes for /api/v1/students
router.route('/')
    .get(studentController.getAllStudents)
    .post(middlewares.checkStudentBody, studentController.createStudent);

// Routes for /api/v1/students/:id
router.route('/:id')
    .get(studentController.getStudentById)
    .patch(studentController.updateStudentById)
    .delete(studentController.deleteStudentById);

module.exports = router;