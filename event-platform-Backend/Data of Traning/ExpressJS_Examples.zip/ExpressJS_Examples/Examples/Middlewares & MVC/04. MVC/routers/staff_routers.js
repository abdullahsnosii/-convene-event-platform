const express = require('express');
const staffController = require('../controllers/staffController');
const middlewares = require('../middlewares/middlewares');

const router = express.Router();

// Apply middleware to all staff routes with ID parameter
router.param('id', middlewares.validateStaffId);

// Routes for /api/v1/staff
router.route('/')
    .get(staffController.getAllStaff)
    .post(middlewares.checkStaffBody, staffController.createStaff);

// Routes for /api/v1/staff/:id
router.route('/:id')
    .get(staffController.getStaffById)
    .patch(staffController.updateStaffById)
    .delete(staffController.deleteStaffById);

module.exports = router;