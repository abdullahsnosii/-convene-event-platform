// Middleware in Express.js
// Middleware functions are functions that have access to the request object (req), the response object (res), and the next middleware function in the application’s request-response cycle.
// Middleware can execute code, make changes to the request and response objects, end the request-response cycle, and call the next middleware function in the stack.
// Custom Middleware, Built-in Middleware, Third-party Middleware

const { create } = require('domain');
const express = require('express');
const fs = require('fs');

data = fs.readFileSync(`${__dirname}/../students.json`, 'utf8');
const students = JSON.parse(data);

const app = express();


const getAllStudents =  (req, res) => {
    res.status(200).json(
        {
            status: 'success',
            results: students.length,
            data: {
                requestTime: req.requestTime,
                students : students
            }
        }
    );
}

const createStudent = (req, res) => {
    console.log(req.body);
    const newStudent = req.body;
    newStudent.id = students.length + 10; // Simulate ID assignment
    students.push(newStudent);
    fs.writeFile(`${__dirname}/../students.json`, JSON.stringify(students, null, 2), err => {
        if (err) {
            return res.status(500).json({ message: 'Failed to save student' });
        }
        res
        .status(201)
        .json(
            {
                message: 'Student created',
                requestTime: req.requestTime
            }
        );
    });
}

const getStudentById = (req, res) => {
    const studentId = req.params.id * 1; // Convert to number
    const student = students.find(s => s.id === studentId);
    if (student) {
        res.status(200).json(student);
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
}

const deleteStudentById = (req, res) => {
    const studentId = req.params.id * 1;
    const studentIndex = students.findIndex(s => s.id === studentId);
    if (studentIndex !== -1) {
        students.splice(studentIndex, 1);
        fs.writeFile(`${__dirname}/../students.json`, JSON.stringify(students, null, 2), err => {
            if (err) {
                return res.status(500).json({ message: 'Failed to delete student' });
            }
            res.status(204).send();
        });
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
}


// Middleware to log request details
app.use((req, res, next) => {
    const now = new Date();
    // console.log(`[${now.toISOString()}] ${req.method} ${req.originalUrl}`);
    console.log(`Hello from the middleware 👋`);
    next();
});

// add time to request
app.use((req, res, next) => {
    req.requestTime = new Date().toISOString();
    next();
});

// built in middleware
const morgan = require("morgan");
app.use(morgan("dev"));
app.use(express.json());


app.route('/api/v1/students/:id')
    .get(getStudentById)
    .delete(deleteStudentById);


app.route('/api/v1/students')
    .get(getAllStudents)
    .post(createStudent);


app.listen(3000, () => {
    console.log('Server running at http://localhost:3000/')
});