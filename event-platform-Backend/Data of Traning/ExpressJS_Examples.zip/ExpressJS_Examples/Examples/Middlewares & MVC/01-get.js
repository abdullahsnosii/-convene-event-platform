// Exercise 1 — GET all students
//
// Goal: Call GET /api/students and return the JSON array.
//
// What to check:
//
// - Start the server and visit http://localhost:3000/api/students
// - Response should be the array from `data/students.json`

const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'Classwork', 'data', 'students.json');
const raw = fs.readFileSync(dataPath, 'utf8');
const students = JSON.parse(raw);

console.log(JSON.stringify(students, null, 2));
