/*
=========================================
Name: validateUser.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/


module.exports = (req, res, next) => {
  const { name, email, age } = req.body;
  if (!name || !email || typeof age !== 'number') {
    return res.status(400).json({ error: 'Name, email, and age are required, age must be a number.' });
  }
  next();
};
