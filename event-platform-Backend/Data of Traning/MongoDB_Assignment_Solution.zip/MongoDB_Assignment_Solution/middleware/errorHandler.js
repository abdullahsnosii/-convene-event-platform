/*
=========================================
Name: errorHandler.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/


module.exports = (err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong', details: err.message });
};
