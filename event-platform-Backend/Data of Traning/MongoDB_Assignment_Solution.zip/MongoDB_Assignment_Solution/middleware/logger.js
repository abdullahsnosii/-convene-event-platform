/*
=========================================
Name: logger.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/


const fs = require('fs');
const path = require('path');

const logFile = path.join(__dirname, '../requests.log');

module.exports = (req, res, next) => {
  res.on('finish', () => {
    const log = `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} ${res.statusCode}\n`;
    fs.appendFile(logFile, log , (err) => {
      if (err) {
        console.error('Failed to write request log:', err);
      }
    });
  });
  next();
};
