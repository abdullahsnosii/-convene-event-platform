/*
=========================================
Name: server.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const userRouter = require('./routes/userRoutes');
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');

const app = express();
app.use(express.json());
app.use(logger);

const dbName = process.env.DB_NAME || 'user_mgmt';
const mongoDBUri = process.env.MONGODB_URI
const MONGODB_URI = mongoDBUri.replace('<DB_NAME>', dbName);

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

app.use('/users', userRouter);
app.use(errorHandler);

app.listen(3000, () => console.log('Server running on port 3000'));
