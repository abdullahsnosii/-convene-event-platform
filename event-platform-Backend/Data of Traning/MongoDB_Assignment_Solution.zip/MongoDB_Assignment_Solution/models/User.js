/*
=========================================
Name: User.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/


const mongoose = require('mongoose');
const userSchema = require('./user_schema');

module.exports = mongoose.model('User', userSchema);
