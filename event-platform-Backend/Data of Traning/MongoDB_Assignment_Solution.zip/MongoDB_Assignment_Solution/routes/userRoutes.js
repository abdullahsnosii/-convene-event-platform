/*
=========================================
Name: user_router.js
Description: Part of the User Management System Assignment solution
Copyright: Edges for Training
=========================================
*/


const express = require('express');
const router = express.Router();
const validateUser = require('../middleware/validateUser');
const userController = require('../controllers/user_controller');

// POST /users
router.post('/', validateUser, userController.createUser);

// GET /users
router.get('/', userController.getUsers);

// GET /users/:id
router.get('/:id', userController.getUserById);

// PUT /users/:id
router.put('/:id', validateUser, userController.updateUser);

// DELETE /users/:id
router.delete('/:id', userController.deleteUser);

module.exports = router;
