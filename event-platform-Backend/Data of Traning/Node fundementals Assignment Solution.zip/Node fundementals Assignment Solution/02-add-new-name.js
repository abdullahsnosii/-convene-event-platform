// Solution for Filesystem Assignment 2: Add a New Name
const fs = require('fs');
fs.appendFileSync('data.txt', 'David\n', 'utf8');
console.log('Added David to data.txt');