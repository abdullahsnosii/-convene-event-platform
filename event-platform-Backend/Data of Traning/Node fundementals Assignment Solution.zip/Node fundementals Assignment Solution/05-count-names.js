// Solution for Filesystem Assignment 5: Count Names
const fs = require('fs');
const names = fs.readFileSync('data.txt', 'utf8').split(/\r?\n/).filter(Boolean);
console.log('Total names:', names.length);