// Solution for Filesystem Assignment 3: List All Names
const fs = require('fs');
const names = fs.readFileSync('data.txt', 'utf8').split(/\r?\n/).filter(Boolean);
names.forEach(name => console.log(name));