// Solution for Filesystem Assignment 1: Create a Data File
const fs = require('fs');
fs.writeFileSync('data.txt', 'Alice\nBob\nCharlie\n', 'utf8');
console.log('Created data.txt');