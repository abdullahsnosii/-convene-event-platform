// Solution for Filesystem Assignment 4: Remove a Name
const fs = require('fs');
const nameToRemove = 'Bob';
const names = fs.readFileSync('data.txt', 'utf8').split(/\r?\n/).filter(Boolean);
const filtered = names.filter(name => name !== nameToRemove);
fs.writeFileSync('data.txt', filtered.join('\n') + '\n', 'utf8');
console.log(`Removed ${nameToRemove} from data.txt`);