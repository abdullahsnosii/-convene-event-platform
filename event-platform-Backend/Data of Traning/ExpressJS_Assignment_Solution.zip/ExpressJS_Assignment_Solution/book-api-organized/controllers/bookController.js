// Book Controller
// Contains all the business logic for book operations

const fs = require('fs');
const path = require('path');

// Path to books data file
const booksFilePath = path.join(__dirname, '../data/books.json');

// Helper function to read books from file
const readBooksFromFile = () => {
  try {
    const data = fs.readFileSync(booksFilePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading books file:', error);
    return [];
  }
};

// Helper function to write books to file
const writeBooksToFile = (books) => {
  try {
    fs.writeFileSync(booksFilePath, JSON.stringify(books, null, 2));
    return true;
  } catch (error) {
    console.error('Error writing books file:', error);
    return false;
  }
};

// Get all books
const getAllBooks = (req, res) => {
  try {
    const books = readBooksFromFile();
    res.json(books);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving books' });
  }
};

// Get book by ID
const getBookById = (req, res) => {
  try {
    const books = readBooksFromFile();
    const book = books.find(b => b.id === parseInt(req.params.id));
    
    if (!book) {
      return res.status(404).json({ message: 'Book not found.' });
    }
    
    res.json(book);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving book' });
  }
};

// Add new book
const addBook = (req, res) => {
  try {
    const books = readBooksFromFile();
    const newBook = { 
      id: books.length > 0 ? Math.max(...books.map(b => b.id)) + 1 : 1,
      ...req.body 
    };
    
    books.push(newBook);
    
    if (writeBooksToFile(books)) {
      res.status(201).json(newBook);
    } else {
      res.status(500).json({ message: 'Error saving book' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error creating book' });
  }
};

// Update book
const updateBook = (req, res) => {
  try {
    const books = readBooksFromFile();
    const book = books.find(b => b.id === parseInt(req.params.id));
    
    if (!book) {
      return res.status(404).json({ message: 'Book not found.' });
    }
    
    // Update book properties
    book.title = req.body.title;
    book.author = req.body.author;
    if (req.body.genre) book.genre = req.body.genre;
    if (req.body.publishedYear) book.publishedYear = req.body.publishedYear;
    if (req.body.pages) book.pages = req.body.pages;
    if (req.body.description) book.description = req.body.description;
    if (req.body.isbn) book.isbn = req.body.isbn;
    
    if (writeBooksToFile(books)) {
      res.json(book);
    } else {
      res.status(500).json({ message: 'Error updating book' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error updating book' });
  }
};

// Delete book
const deleteBook = (req, res) => {
  try {
    const books = readBooksFromFile();
    const index = books.findIndex(b => b.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ message: 'Book not found.' });
    }
    
    books.splice(index, 1);
    
    if (writeBooksToFile(books)) {
      res.status(204).send();
    } else {
      res.status(500).json({ message: 'Error deleting book' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error deleting book' });
  }
};

module.exports = {
  getAllBooks,
  getBookById,
  addBook,
  updateBook,
  deleteBook
};