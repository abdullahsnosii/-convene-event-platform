// Book API Server
// Simple Express.js server with middleware demonstration

const express = require('express');
const morgan = require('morgan');

// Import custom middleware
const logger = require('./middlewares/logger');

// Import routes
const bookRoutes = require('./routes/books');

// Create Express application
const app = express();

// Built-in middleware
app.use(express.json());           // Parse JSON bodies

// Third-party middleware
app.use(morgan('dev'));            // HTTP request logger

// Custom middleware
app.use(logger);                   // Custom logger

// Welcome route
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to Book API!',
    version: '1.0.0',
    endpoints: {
      'GET /api/books': 'Get all books',
      'GET /api/books/:id': 'Get book by ID',
      'POST /api/books': 'Create new book (requires title and author)',
      'PUT /api/books/:id': 'Update book (requires title and author)',
      'DELETE /api/books/:id': 'Delete book'
    },
    example: {
      createBook: {
        method: 'POST',
        url: '/api/books',
        body: {
          title: 'Example Book',
          author: 'Example Author',
          genre: 'Fiction',
          publishedYear: 2023,
          pages: 300,
          description: 'An example book description'
        }
      }
    }
  });
});

// Mount book routes
app.use('/api/books', bookRoutes);

// Error handling middleware (Bonus Challenge)
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something broke!' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log('📚 BOOK API SERVER STARTED');
  console.log('='.repeat(50));
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📖 API Documentation: http://localhost:${PORT}/`);
  console.log(`📚 Books endpoint: http://localhost:${PORT}/api/books`);
  console.log('='.repeat(50));
  console.log('Available endpoints:');
  console.log('  GET    /                 - API documentation');
  console.log('  GET    /api/books        - Get all books');
  console.log('  GET    /api/books/:id    - Get book by ID');
  console.log('  POST   /api/books        - Create new book');
  console.log('  PUT    /api/books/:id    - Update book');
  console.log('  DELETE /api/books/:id    - Delete book');
  console.log('='.repeat(50));
});

module.exports = app;