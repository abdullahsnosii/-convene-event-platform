// Simple book validation middleware
// Validates only the essential book fields: title and author

module.exports = (req, res, next) => {
  const { title, author } = req.body;
  
  // Check if title and author are provided
  if (!title || !author) {
    return res.status(400).json({ 
      message: 'Book title and author are required.' 
    });
  }
  
  // Check if title and author are not empty strings
  if (title.trim() === '' || author.trim() === '') {
    return res.status(400).json({ 
      message: 'Book title and author cannot be empty.' 
    });
  }
  
  console.log(`[${new Date().toISOString()}] Book validation passed for: "${title}" by ${author}`);
  next();
};