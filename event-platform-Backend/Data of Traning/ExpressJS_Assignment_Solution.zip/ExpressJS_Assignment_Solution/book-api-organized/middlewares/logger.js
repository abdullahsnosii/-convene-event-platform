// Simple custom logger middleware
// Logs incoming requests with timestamp, method, and URL

module.exports = (req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
};