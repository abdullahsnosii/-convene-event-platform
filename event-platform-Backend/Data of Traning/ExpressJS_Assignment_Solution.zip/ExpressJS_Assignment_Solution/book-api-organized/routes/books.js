// Book Routes
// Defines all the routes for book operations with middleware chaining

const express = require('express');
const router = express.Router();

// Import middlewares
const validateBook = require('../middlewares/validateBook');

// Import controller
const bookController = require('../controllers/bookController');

// Routes with middleware chaining
router.route('/')
  .get(bookController.getAllBooks)                    // GET /api/books 
  .post( validateBook, bookController.addBook);  // POST /api/books -  validation

router.route('/:id')
  .get(bookController.getBookById)                           // GET /api/books/:id 
  .put( validateBook, bookController.updateBook)        // PUT /api/books/:id - validation
  .delete( bookController.deleteBook);                  // DELETE /api/books/:id 

module.exports = router;