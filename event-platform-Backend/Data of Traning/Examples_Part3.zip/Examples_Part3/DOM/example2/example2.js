/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Using document.querySelector and document.querySelectorAll
 ============================================================================
 */

// Select using ID
let title = document.querySelector("#title");
console.log("Query by ID:", title.textContent);

// Select first element by class
let firstParagraph = document.querySelector(".description");
console.log("Query by Class (first match):", firstParagraph.textContent);

// Select all elements by class (returns NodeList)
let allParagraphs = document.querySelectorAll(".description");
allParagraphs.forEach((p) => console.log("Query All by Class:", p.textContent));

// Select input field using name attribute
let usernameInput = document.querySelector("[name='username']");
console.log("Query by Name:", usernameInput.value);
