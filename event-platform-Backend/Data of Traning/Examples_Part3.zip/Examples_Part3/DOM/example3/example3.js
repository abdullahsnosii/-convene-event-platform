/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Demonstrating Live vs. Static Behavior
 ============================================================================
 */

// Selecting elements using HTMLCollection (live)
let liveCollection = document.getElementsByClassName("item");

// Selecting elements using NodeList (static)
let staticNodeList = document.querySelectorAll(".item");

function addItem() {
  // Creating a new list item
  let newItem = document.createElement("li");
  newItem.className = "item";
  newItem.textContent = "New Item";

  // Appending to the list
  document.getElementById("list").appendChild(newItem);

  console.log("HTMLCollection (Live):", liveCollection.length); // Updates immediately
  console.log("NodeList (Static):", staticNodeList.length); // Remains the same
}

console.log("Initial HTMLCollection:", liveCollection.length); // 2
console.log("Initial NodeList:", staticNodeList.length); // 2
