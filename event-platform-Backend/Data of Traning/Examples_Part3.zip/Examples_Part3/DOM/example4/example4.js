/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Example Demonstrating Access by Name and ID
 ============================================================================
 */

// Getting the HTMLCollection from the form elements
let formElements = document.forms["myForm"].elements;

// Accessing elements by index (like an array)
console.log(formElements[0].value); // Output: JohnDoe

// Accessing elements by their `name` attribute (specific to HTMLCollection)
console.log(formElements["username"].value); // Output: JohnDoe
console.log(formElements["email"].value); // Output: john@example.com

// Accessing elements by their `id` (also works in some cases)
console.log(formElements.username.value); // Output: JohnDoe
console.log(formElements.email.value); // Output: john@example.com
