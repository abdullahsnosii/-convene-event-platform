/*
 ============================================================================
 Name        : Example11
 Copyright   : Edges For Training
 Description : A simple interactive task manager
 ============================================================================
 */

document.addEventListener("DOMContentLoaded", function () {
  let taskInput = document.getElementById("taskInput");
  let addTaskBtn = document.getElementById("addTaskBtn");
  let taskContainer = document.getElementById("taskContainer");

  // Function to add a new task
  function addTask() {
    let taskText = taskInput.value.trim();

    if (taskText === "") {
      alert("Please enter a task!");
      return;
    }

    // Create a new task div
    let taskDiv = document.createElement("div");
    taskDiv.textContent = taskText;
    taskDiv.classList.add("task");

    // Add mouseover and click event listeners
    taskDiv.addEventListener("mouseover", function () {
      taskDiv.style.backgroundColor = "lightgreen"; // Change color on hover
    });

    taskDiv.addEventListener("mouseout", function () {
      taskDiv.style.backgroundColor = "lightblue"; // Revert color
    });

    taskDiv.addEventListener("click", function () {
      taskDiv.remove(); // Remove task on click
    });

    // Append the new task to the container
    taskContainer.appendChild(taskDiv);
    taskInput.value = ""; // Clear input
  }

  // Event listener for button click
  addTaskBtn.addEventListener("click", addTask);

  // Event listener for pressing Enter in the input field
  taskInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      addTask();
    }
  });
});
