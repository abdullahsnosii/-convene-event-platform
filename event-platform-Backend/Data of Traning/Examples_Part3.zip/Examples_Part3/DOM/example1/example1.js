/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : getElementBy example
 ============================================================================
 */

// Get element by ID
let title = document.getElementById("title");
console.log("By ID:", title);

// Get elements by class name (returns a collection)
let descriptions = document.getElementsByClassName("description");
console.log("By Class:", descriptions[0], descriptions[1]);

// Get elements by tag name (returns a collection)
let paragraphs = document.getElementsByTagName("p");
console.log("By Tag:", paragraphs[0].textContent, paragraphs[1].textContent);

// Get elements by name (returns a collection)
let usernameInput = document.getElementsByName("username");
console.log("By Name:", usernameInput[0].value);
