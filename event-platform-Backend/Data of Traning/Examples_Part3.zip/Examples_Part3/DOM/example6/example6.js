/*
 ============================================================================
 Name        : Example6
 Copyright   : Edges For Training
 Description : Using appendChild to Add Elements Dynamically
 ============================================================================
 */

function addItem() {
  let list = document.getElementById("itemList");

  // Create a new list item
  let newItem = document.createElement("li");
  newItem.textContent = "New Item";

  // Append the new item to the end of the list
  list.appendChild(newItem);
}
