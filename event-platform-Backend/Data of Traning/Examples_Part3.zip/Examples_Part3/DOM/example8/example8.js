/*
 ============================================================================
 Name        : Example8
 Copyright   : Edges For Training
 Description : Using addEventListener to Handle Click Events
 ============================================================================
 */

// Select the button and paragraph
let button = document.getElementById("myButton");
let message = document.getElementById("message");

// Add a click event listener to the button
button.addEventListener("click", function () {
  message.textContent = "Button Clicked!";
  button.style.backgroundColor = "green"; // Change button color
});
