/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : Using .innerHTML to Get and Set Content
 ============================================================================
 */

function updateContent() {
  let contentDiv = document.getElementById("content");

  // Get current HTML content
  console.log("Before update:", contentDiv.innerHTML);

  // Set new HTML content
  contentDiv.innerHTML =
    "<h3>New Content Added</h3><p>This paragraph is new.</p>";

  // Log updated content
  console.log("After update:", contentDiv.innerHTML);
}
