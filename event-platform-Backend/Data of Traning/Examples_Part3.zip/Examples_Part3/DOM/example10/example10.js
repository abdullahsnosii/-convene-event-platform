/*
 ============================================================================
 Name        : Example10
 Copyright   : Edges For Training
 Description : keydown Event Listener (Detecting Key Presses)
 ============================================================================
 */
let inputBox = document.getElementById("inputBox");
let keyOutput = document.getElementById("keyOutput");

// Listen for key presses
inputBox.addEventListener("keydown", function (event) {
  keyOutput.textContent = "Pressed key: " + event.key;
});
