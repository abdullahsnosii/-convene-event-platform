/*
 ============================================================================
 Name        : Example9
 Copyright   : Edges For Training
 Description : mouseover and mouseout Event Listeners
 ============================================================================
 */

let hoverBox = document.getElementById("hoverBox");

// Change background on mouseover
hoverBox.addEventListener("mouseover", function () {
  hoverBox.style.backgroundColor = "yellow";
  hoverBox.textContent = "Mouse Over!";
});

// Revert background on mouseout
hoverBox.addEventListener("mouseout", function () {
  hoverBox.style.backgroundColor = "lightgray";
  hoverBox.textContent = "Hover over me";
});
