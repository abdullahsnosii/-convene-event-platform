/*
 ============================================================================
 Name        : Example7
 Copyright   : Edges For Training
 Description :  Changing Styles Using JavaScript
 ============================================================================
 */
function changeStyle() {
  let box = document.getElementById("box");

  // Accessing and modifying styles using camelCase
  box.style.backgroundColor = "red"; // Changes background color
  box.style.width = "150px"; // Increases width
  box.style.height = "150px"; // Increases height
  box.style.borderRadius = "10px"; // Adds rounded corners
  box.style.fontSize = "20px"; // Increases text size
  box.style.fontWeight = "bold"; // Makes text bold
}
