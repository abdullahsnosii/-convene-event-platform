/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : Fetching API Data with Error Handling
 ============================================================================
 */

async function fetchUserData() {
  try {
    console.log("⏳ Fetching user data...");
    const response = await fetch(
      "https://jsonplaceholder.typicode.com/users/1"
    );

    if (!response.ok) {
      throw new Error(`❌ HTTP Error! Status: ${response.status}`);
    }

    const user = await response.json();
    console.log("✅ User fetched:", user);
  } catch (error) {
    console.error("🔥 Error:", error.message);
  } finally {
    console.log("🔄 Operation complete!");
  }
}

fetchUserData();
