/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Handling Errors with try...catch
 ============================================================================
 */

function fetchUser() {
  return new Promise((resolve, reject) => {
    setTimeout(() => reject("❌ Failed to fetch user"), 1000);
  });
}

async function getUser() {
  try {
    console.log("⏳ Fetching user...");
    const user = await fetchUser(); // If this fails, it jumps to catch block
    console.log("✅ User fetched:", user);
  } catch (error) {
    console.error("🔥 Error caught:", error);
  } finally {
    console.log("🔄 Operation complete!");
  }
}

getUser();
