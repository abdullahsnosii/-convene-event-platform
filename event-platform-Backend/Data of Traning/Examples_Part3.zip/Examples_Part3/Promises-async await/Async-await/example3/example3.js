/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Multiple await Calls 
 ============================================================================
 */

function fetchUser() {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id: 1, name: "Alice" }), 1000);
  });
}

function fetchPosts(userId) {
  return new Promise((resolve) => {
    setTimeout(
      () =>
        resolve([`Post 1 from user ${userId}`, `Post 2 from user ${userId}`]),
      1000
    );
  });
}

async function getUserData() {
  console.log("⏳ Fetching user...");
  const user = await fetchUser();
  console.log("✅ User fetched:", user);

  console.log("⏳ Fetching posts...");
  const posts = await fetchPosts(user.id);
  console.log("✅ Posts fetched:", posts);
}

getUserData();
