/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Basic async/await Structure
 ============================================================================
 */

function fetchUser() {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id: 1, name: "Alice" }), 1000);
  });
}

async function getUser() {
  console.log("⏳ Fetching user...");
  const user = await fetchUser(); // Waits for the Promise to resolve
  console.log("✅ User fetched:", user);
}

getUser();
console.log("🚀 Code continues executing...");
