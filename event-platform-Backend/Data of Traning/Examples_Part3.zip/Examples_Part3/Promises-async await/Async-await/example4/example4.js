/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Running Multiple Promises in Parallel 
 ============================================================================
 */

function fetchComments() {
  return new Promise((resolve) => {
    setTimeout(() => resolve(["Comment 1", "Comment 2"]), 2000);
  });
}

function fetchLikes() {
  return new Promise((resolve) => {
    setTimeout(() => resolve(150), 2000);
  });
}

async function getPostDetails() {
  console.log("⏳ Fetching comments and likes...");

  const [comments, likes] = await Promise.all([fetchComments(), fetchLikes()]);

  console.log("✅ Comments:", comments);
  console.log("👍 Likes:", likes);
}

getPostDetails();
