/*
 ============================================================================
 Name        : Example7
 Copyright   : Edges For Training
 Description : Promise.allSettled() - Waits for All (Never Fails)
 ============================================================================
 */

const p1 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P1 Done"), 1000)
);
const p2 = new Promise((_, reject) =>
  setTimeout(() => reject("❌ P2 Failed"), 500)
);
const p3 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P3 Done"), 1500)
);

Promise.allSettled([p1, p2, p3]).then((results) =>
  console.log("All Settled:", results)
);
