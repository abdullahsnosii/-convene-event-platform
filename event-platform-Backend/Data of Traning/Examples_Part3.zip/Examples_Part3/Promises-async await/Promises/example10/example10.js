/*
 ============================================================================
 Name        : Example10
 Copyright   : Edges For Training
 Description : An e-commerce platform that fetches user data, order details, 
            and shipping status asynchronously
 ============================================================================
 */

// Simulate API calls with random delays
const fetchUser = new Promise((resolve) =>
  setTimeout(() => resolve({ id: 1, name: "Alice" }), 1000)
);
const fetchOrders = new Promise((resolve, reject) =>
  setTimeout(() => reject("❌ Order service failed"), 1200)
);
const fetchShipping = new Promise((resolve) =>
  setTimeout(() => resolve("🚚 Shipped"), 800)
);

// 🌟 1️⃣ Using `Promise.all()` - Fetch all data, but fail fast if any service fails
Promise.all([fetchUser, fetchOrders, fetchShipping])
  .then(([user, orders, shipping]) =>
    console.log("✅ All Data:", { user, orders, shipping })
  )
  .catch((error) => console.error("Promise.all Failed:", error));

// 🌟 2️⃣ Using `Promise.allSettled()` - Fetch all data and handle failures individually
Promise.allSettled([fetchUser, fetchOrders, fetchShipping]).then((results) =>
  console.log("✅ AllSettled Results:", results)
);

// 🌟 3️⃣ Using `Promise.race()` - Find the fastest response (resolve or reject)
Promise.race([fetchUser, fetchOrders, fetchShipping])
  .then((fastest) => console.log("🏆 Fastest Response:", fastest))
  .catch((error) => console.error("Race Failed:", error));

// 🌟 4️⃣ Using `Promise.any()` - Return first successful promise, ignoring failures
Promise.any([fetchOrders, fetchShipping])
  .then((firstSuccess) => console.log("🎉 First Success:", firstSuccess))
  .catch((error) => console.error("All Failed (Any):", error.errors));

// 🌟 5️⃣ Chaining `.then()` and multiple `.catch()`
fetchUser
  .then((user) => {
    console.log("🧑 User Fetched:", user);
    return fetchOrders; // Next step: Fetch orders
  })
  .then((orders) => {
    console.log("📦 Orders:", orders);
    return fetchShipping; // Next step: Fetch shipping
  })
  .then((shipping) => console.log("🚚 Shipping Status:", shipping))
  .catch((error) => console.error("🔥 Error in Chain:", error))
  .finally(() => console.log("🔄 Process Complete!"));
