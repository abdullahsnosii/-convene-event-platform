/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Weather Check Simulation
 ============================================================================
 */

function getWeather(city) {
  return new Promise((resolve, reject) => {
    console.log(`Fetching weather for ${city}...`);

    setTimeout(() => {
      const weatherData = {
        Cairo: { temperature: 30, condition: "Sunny" },
        London: { temperature: 15, condition: "Rainy" },
        Tokyo: { temperature: 22, condition: "Cloudy" },
      };

      if (weatherData[city]) {
        resolve(
          `The weather in ${city} is ${weatherData[city].condition} with ${weatherData[city].temperature}°C.`
        );
      } else {
        reject("Weather data not available for this city.");
      }
    }, 2000);
  });
}

// Calling the function with .then() and .catch()
getWeather("Cairo")
  .then((data) => {
    console.log("Weather Info:", data);
  })
  .catch((error) => {
    console.error("Error:", error);
  })
  .finally(() => {
    console.log("Weather check completed.");
  })
  .then(() => console.log("1 after finally"))
  .then(() => console.log("2 after finally"))
  .then(() => console.log("3 after finally"))
  .catch(() => console.log("Error after finally"));
