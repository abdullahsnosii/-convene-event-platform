/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : Multi-Step Promise Chaining Example
 ============================================================================
 */

function placeOrder(orderId) {
  return new Promise((resolve, reject) => {
    console.log(`Placing order #${orderId}...`);
    setTimeout(() => {
      if (orderId > 100) {
        resolve(orderId);
      } else {
        reject("Invalid order ID!");
      }
    }, 1000);
  });
}

function processPayment(orderId) {
  return new Promise((resolve, reject) => {
    console.log(`Processing payment for order #${orderId}...`);
    setTimeout(() => {
      if (orderId % 2 !== 0) {
        reject("Payment failed due to insufficient balance!");
      } else {
        resolve(`Payment successful for order #${orderId}`);
      }
    }, 1000);
  });
}

function shipOrder(orderId) {
  return new Promise((resolve) => {
    console.log(`Shipping order #${orderId}...`);
    setTimeout(() => {
      resolve(`Order #${orderId} has been shipped!`);
    }, 1000);
  });
}

// Chaining multiple `.then()`
placeOrder(101)
  .then((orderId) => {
    console.log("Order placed successfully!");
    return processPayment(orderId); // Passing orderId to next `.then()`
  })
  .then((paymentStatus) => {
    console.log(paymentStatus);
    return shipOrder(101); // Order is now being shipped
  })
  .then((shippingStatus) => {
    console.log(shippingStatus);
  })
  .catch((error) => {
    console.error("Order Error:", error);
    throw new Error("Critical failure!"); // This will be caught by the next `.catch()`
  })
  .catch((error) => {
    console.error("Recovery Attempt Failed:", error.message);
  })
  .finally(() => {
    console.log("Order process completed.");
  })
  .then(() => {
    console.log(
      "This runs even after `.finally()` because `.then()` can be added after it."
    );
  });
