/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Understanding Promises Structure
 ============================================================================
 */

// Creating a Promise
const myPromise = new Promise((resolve, reject) => {
  let success = true; // Change this to false to test rejection

  setTimeout(() => {
    if (success) {
      resolve("Operation Successful!"); // Resolved state
    } else {
      reject("Operation Failed!"); // Rejected state
    }
  }, 2000); // Simulating async work
});

// Handling the Promise
myPromise
  .then((message) => {
    console.log("Success:", message);
  })
  .catch((error) => {
    console.error("Error:", error);
  })
  .finally(() => {
    console.log("Promise execution completed.");
  });
