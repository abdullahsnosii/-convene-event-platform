/*
 ============================================================================
 Name        : Example8
 Copyright   : Edges For Training
 Description : Promise.race() - First Wins (Success or Failure)
 ============================================================================
 */

const p1 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P1 Won!"), 1000)
);
const p2 = new Promise((_, reject) =>
  setTimeout(() => reject("❌ P2 Lost!"), 500)
);
const p3 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P3 Won!"), 2000)
);

Promise.race([p1, p2, p3])
  .then((winner) => console.log("Winner:", winner))
  .catch((error) => console.error("Race Failed:", error));
