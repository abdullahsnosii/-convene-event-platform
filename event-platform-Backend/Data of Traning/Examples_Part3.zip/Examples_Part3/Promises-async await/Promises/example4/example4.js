/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Chaining .then() on a Single Promise
 ============================================================================
 */

const numberProcessing = new Promise((resolve, reject) => {
  console.log("Starting with a number...");
  setTimeout(() => {
    resolve(5); // Initial value
  }, 1000);
});

numberProcessing
  .then((num) => {
    console.log(`Received: ${num}`);
    return num * 2; // Passes 10 to the next `.then()`
  })
  .then((num) => {
    console.log(`Doubled: ${num}`);
    return num + 3; // Passes 13 to the next `.then()`
  })
  .then((num) => {
    console.log(`Added 3: ${num}`);
    return num / 2; // Passes 6.5 to the next `.then()`
  })
  .then((num) => {
    console.log(`Divided by 2: ${num}`);
    return `Final Result: ${num}`; // Passes final result as a string
  })
  .then((message) => {
    console.log(message); // Logs the final result
  })
  .catch((error) => {
    console.error("Error:", error);
  })
  .finally(() => {
    console.log("Processing completed.");
  });
