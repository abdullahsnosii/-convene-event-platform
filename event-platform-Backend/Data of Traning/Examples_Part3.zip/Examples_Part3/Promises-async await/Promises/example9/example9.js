/*
 ============================================================================
 Name        : Example9
 Copyright   : Edges For Training
 Description : Promise.any() - First Success Wins
 ============================================================================
 */

const p1 = new Promise((_, reject) =>
  setTimeout(() => reject("❌ P1 Failed"), 1000)
);
const p2 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P2 Won!"), 500)
);
const p3 = new Promise((_, reject) =>
  setTimeout(() => reject("❌ P3 Failed"), 2000)
);

Promise.any([p1, p2, p3])
  .then((result) => console.log("First Success:", result))
  .catch((error) => console.error("All Failed:", error.errors));
