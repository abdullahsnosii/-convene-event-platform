/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Fetching User Data (Simulated API Call)
 ============================================================================
 */

function fetchUserData(userId) {
  return new Promise((resolve, reject) => {
    console.log("Fetching user data...");

    setTimeout(() => {
      const users = {
        1: { name: "Alice", age: 25 },
        2: { name: "Bob", age: 30 },
      };

      if (users[userId]) {
        resolve(users[userId]); // Resolving with user data
      } else {
        reject("User not found!"); // Rejecting with an error
      }
    }, 2000);
  });
}

// Calling the function with .then() and .catch()
fetchUserData(1)
  .then((user) => {
    console.log("User Data:", user);
  })
  .catch((error) => {
    console.error("Error:", error);
  })
  .finally(() => {
    console.log("Finished fetching user data.");
  });
