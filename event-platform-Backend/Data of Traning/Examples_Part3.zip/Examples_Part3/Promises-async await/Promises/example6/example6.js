/*
 ============================================================================
 Name        : Example6
 Copyright   : Edges For Training
 Description : Promise.all() - Waits for All (Fails Fast)

 ============================================================================
 */

const p1 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P1 Done"), 1000)
);
const p2 = new Promise((resolve) =>
  setTimeout(() => resolve("✅ P2 Done"), 1500)
);
const p3 = new Promise((_, reject) =>
  setTimeout(() => reject("❌ P3 Failed"), 500)
);

Promise.all([p1, p2, p3])
  .then((results) => console.log("All Success:", results))
  .catch((error) => console.error("Promise.all Failed:", error));
