/*
=========================================
Name: solution.js
Description: Mongoose solution to in-class task with Express.js API endpoints for User and Post, including validation and virtuals
Copyright: Edges for Training
=========================================
*/

const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());

mongoose.connect('mongodb+srv://<username>:<password>@cluster.mongodb.net/edges_training', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("Connection error", err));

// User Schema
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  age: { type: Number, min: 18 }
});

// Post Schema
const postSchema = new mongoose.Schema({
  title: String,
  content: String,
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

// Virtual property for post summary
postSchema.virtual('summary').get(function() {
  return this.content.slice(0, 50);
});

postSchema.set('toObject', { virtuals: true });
postSchema.set('toJSON', { virtuals: true });

const User = mongoose.model('User', userSchema);
const Post = mongoose.model('Post', postSchema);

// Create new user
app.post('/user', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Create new post
app.post('/post', async (req, res) => {
  try {
    const post = new Post(req.body);
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get all posts with populated user and summary
app.get('/post', async (req, res) => {
  const posts = await Post.find().populate('author');
  res.json(posts.map(post => post.toObject()));
});

// Start server
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
