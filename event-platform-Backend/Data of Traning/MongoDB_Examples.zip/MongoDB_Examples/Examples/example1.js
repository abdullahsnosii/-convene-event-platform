/*
=========================================
Name: example5.js
Description: CRUD operations in Mongoose using save, find, updateOne, findOneAndUpdate, deleteOne
Copyright: Edges for Training
=========================================
*/

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://<username>:<password>@cluster.mongodb.net/edges_training');

const User = mongoose.model('User', new mongoose.Schema({
  name: String,
  email: String,
  age: Number
}));

const user = new User({ name: 'Alice', email: 'alice@example.com', age: 25 });
user.save().then(console.log);

User.find().then(console.log);
User.findOne({ email: 'alice@example.com' }).then(console.log);
User.updateOne({ email: 'alice@example.com' }, { $set: { age: 26 } }).then(console.log);
User.findOneAndUpdate({ name: 'Alice' }, { age: 27 }, { new: true }).then(console.log);
User.deleteOne({ email: 'alice@example.com' }).then(console.log);
