/*
=========================================
Name: example7.js
Description: Mongoose relationships and population using ref and populate
Copyright: Edges for Training
=========================================
*/

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://<username>:<password>@cluster.mongodb.net/edges_training');

const userSchema = new mongoose.Schema({ name: String });
const postSchema = new mongoose.Schema({
  title: String,
  content: String,
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

const User = mongoose.model('User', userSchema);
const Post = mongoose.model('Post', postSchema);

async function createPost() {
  const user = await User.create({ name: 'Jane' });
  const post = await Post.create({ title: 'My Post', content: 'Hello world', author: user._id });

  const posts = await Post.find().populate('author');
  console.log(posts);
}

createPost();
