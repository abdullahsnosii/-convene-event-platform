/*
=========================================
Name: example6.js
Description: Mongoose virtuals and middleware example
Copyright: Edges for Training
=========================================
*/

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://<username>:<password>@cluster.mongodb.net/edges_training');

const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String
});

userSchema.virtual('fullName').get(function () {
  return this.firstName + ' ' + this.lastName;
});

userSchema.pre('save', function (next) {
  console.log('About to save:', this);
  next();
});

const User = mongoose.model('User', userSchema);
const user = new User({ firstName: 'John', lastName: 'Doe' });
console.log(user.fullName);
user.save();
