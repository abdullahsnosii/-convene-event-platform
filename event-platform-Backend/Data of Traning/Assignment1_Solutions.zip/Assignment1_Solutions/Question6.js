/*
===================================================================================================
Name        : Question6.js
Author      : Edges For Training
Description : Simple calculator using switch-case
===================================================================================================
*/

let operation = '+';
let num1 = 10;
let num2 = 5;
let result;

switch(operation) {
    case '+':
        result = num1 + num2;
        break;
    case '-':
        result = num1 - num2;
        break;
    case '*':
        result = num1 * num2;
        break;
    case '/':
        result = num1 / num2;
        break;
    default:
        console.log("Invalid operation");
}

console.log("Result:", result);