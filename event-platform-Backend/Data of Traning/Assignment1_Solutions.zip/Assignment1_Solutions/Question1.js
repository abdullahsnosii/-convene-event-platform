/*
===================================================================================================
Name        : Question1.js
Author      : Edges For Training
Description : Program that prints your name and age on separate lines
===================================================================================================
*/

// Define name and age
let name = "Edges For Training";
let age = 25; // Replace with your actual age

// Print name and age on separate lines
console.log(name);
console.log(age);