/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to find the greatest common divisor (GCD) of two positive integers 
===================================================================================================
*/

function findGCD(a, b) {
   let num;
   if (a > b) {
      num = a;
   } else {
      num = b
   }
   while (num !== 0) {
      if (a % num === 0 && b % num === 0) {
         return num
      }
      num = num - 1;
   }
   return 1;
}

console.log(findGCD(24, 18));