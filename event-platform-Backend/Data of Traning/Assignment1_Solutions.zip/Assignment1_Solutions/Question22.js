/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to calculate the sum of digits of a given positive integer 
===================================================================================================
*/

function sumDigits(num){
   let count = 0;
   while(num > 0){
      let digit = num % 10;
      sum = sum + digit;
      num = num / 10;
   }
   return count;
}

console.log(sumDigits(819));