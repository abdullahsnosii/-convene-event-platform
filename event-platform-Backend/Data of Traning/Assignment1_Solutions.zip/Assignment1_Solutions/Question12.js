/*
===================================================================================================
Name        : Question12.js
Author      : Edges For Training
Description : Program that displays a full pyramid using stars pattern
===================================================================================================
*/

let rows = 5;
let pattern = '';

for (let i = 1; i <= rows; i++) {
    for (let j = 1; j <= rows - i; j++) {
        pattern += ' ';
    }
    for (let k = 0; k < 2 * i - 1; k++) {
        pattern += '*';
    }
    pattern += '\n';
}

console.log(pattern);