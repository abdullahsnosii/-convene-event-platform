/*
===================================================================================================
Name        : Question7.js
Author      : Edges For Training
Description : Program to print sum of first N integers
===================================================================================================
*/

let N = 100;

let sum;
// Possible Solution 1 (using maths):
sum = (N * (N + 1)) / 2;

// Possible Solution 1 (using maths):
sum = 0;
for(let i = 1; i < 100; i++){
    sum = sum + i;
}

console.log("Sum of first", N, "integers:", sum);