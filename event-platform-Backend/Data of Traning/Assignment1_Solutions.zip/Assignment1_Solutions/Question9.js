/*
===================================================================================================
Name        : Question9.js
Author      : Edges For Training
Description : Program that checks if a number is a perfect square
===================================================================================================
*/

let num = 64;
let isPerfectSquare = Number.isInteger(Math.sqrt(num));

console.log(num, "is a perfect square:", isPerfectSquare);