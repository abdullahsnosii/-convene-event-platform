/*
===================================================================================================
Name        : Question5.js
Author      : Edges For Training
Description : Program that outputs the largest between three numbers
===================================================================================================
*/

let a = 10;
let b = 25;
let c = 15;

let largest = a;
if (b > largest) largest = b;
if (c > largest) largest = c;

console.log("The largest number is:", largest);