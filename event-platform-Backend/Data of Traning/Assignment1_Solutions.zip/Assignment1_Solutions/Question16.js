/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to check if the first number is a multiple of the second 
===================================================================================================
*/

const isMultiple = (num1, num2) => num1 % num2 === 0;

console.log(isMultiple(10, 2));