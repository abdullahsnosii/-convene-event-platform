/*
===================================================================================================
Name        : Question4.js
Author      : Edges For Training
Description : Program that calculates BMI and determines the fitness category
===================================================================================================
*/

// Set weight (in kilograms) and height (in centimeters)
let weight = 70; // kg
let height = 170; // cm

// Calculate BMI (convert height to meters)
let heightInMeters = height / 100;
let bmi = weight / (heightInMeters * heightInMeters);

// Determine fitness category
let fitnessCategory;
if (bmi < 18.5) {
    fitnessCategory = "Underweight";
} else if (bmi < 24.9) {
    fitnessCategory = "Normal weight";
} else if (bmi < 29.9) {
    fitnessCategory = "Overweight";
} else {
    fitnessCategory = "Obesity";
}

// Print the results
console.log("BMI:", bmi.toFixed(2));
console.log("Fitness Category:", fitnessCategory);