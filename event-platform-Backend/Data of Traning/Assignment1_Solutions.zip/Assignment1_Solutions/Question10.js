/*
===================================================================================================
Name        : Question10.js
Author      : Edges For Training
Description : Program that transforms minutes into hours and minutes
===================================================================================================
*/

let totalMinutes = 93;
let hours = Math.floor(totalMinutes / 60);
let minutes = totalMinutes % 60;

console.log(totalMinutes, "minutes is", hours, "hour(s) and", minutes, "minute(s)");