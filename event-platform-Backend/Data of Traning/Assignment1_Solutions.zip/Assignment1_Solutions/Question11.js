/*
===================================================================================================
Name        : Question11.js
Author      : Edges For Training
Description : Program that outputs the multiplication table until 10 for any input integer
===================================================================================================
*/

let num = 7;

for (let i = 1; i <= 10; i++) {
    console.log(num + " x " + i + " = " + (num * i));
}