/*
===================================================================================================
Name        : Question2.js
Author      : Edges For Training
Description : Program that calculates the area and circumference of a circle given its radius
===================================================================================================
*/

// Set the radius
let radius = 5;

// Calculate area and circumference
let area = Math.PI * radius * radius;
let circumference = 2 * Math.PI * radius;

// Print the results
console.log("Area:", area.toFixed(2));
console.log("Circumference:", circumference.toFixed(2)); // toFixed(2) rounds to 2 decimal places so it is readable