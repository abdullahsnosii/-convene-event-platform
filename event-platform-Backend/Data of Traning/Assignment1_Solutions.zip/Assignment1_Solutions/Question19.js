/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to check if a number is a power of two
===================================================================================================
*/

function isPowerOfTwo(number) {
    if (number < 1) {
        return false;
    }

    while (number !== 1) {
        if (number % 2 !== 0) {
            return false;
        }
        number = number / 2;
    }

    return true;
}

console.log(isPowerOfTwo(64));
console.log(isPowerOfTwo(34));