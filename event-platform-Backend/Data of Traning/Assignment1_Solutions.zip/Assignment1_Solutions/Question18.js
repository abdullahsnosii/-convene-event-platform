/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to calculate the number of holes in a given number 
===================================================================================================
*/

function countHoles(num){
   let count = 0;
   while(num > 0){
      let digit = num % 10;
      switch(digit){
         case 0:
         case 4:
         case 6:
         case 9:
            count = count + 1;
            break;
         case 8:
            count = count + 2;
            break;
      }
      num = num / 10;
   }
   return count;
}

console.log(countHoles(819));