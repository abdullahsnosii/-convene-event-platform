/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : function to check if a number is positive or negative 
===================================================================================================
*/

function checkPositiveNegative(number) {
    if (number > 0) {
        console.log("Positive");
    } else if (number < 0) {
        console.log("Negative");
    } else {
        console.log("Zero");
    }
}

checkPositiveNegative(10);
checkPositiveNegative(0);
checkPositiveNegative(-2);