/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to generate the nth Fibonacci number 
===================================================================================================
*/

function fibonacci(n) {
   if (n <= 1) return n;
   let a = 0, b = 1;
   for (let i = 2; i <= n; i++) {
      let temp = a + b;
      a = b;
      b = temp;
   }
   return b;
}