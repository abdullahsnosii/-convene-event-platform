/* ===================================================================================================
Name        : JavaScript Functions Assignment
Author      : Edges For Training
Description : Function to perform arithmetic operations 
===================================================================================================
*/

function performOperation(operation, num1, num2) {
    switch (operation) {
        case 'add':
            return num1 + num2;
        case 'subtract':
            return num1 - num2;
        case 'multiply':
            return num1 * num2;
        case 'divide':
            if (num2 !== 0) {
                return num1 / num2;
            } else {
                return "Error: Division by zero";
            }
        default:
            return "Error: Invalid operation";
    }
}

let result = performOperation("add", 10, 20);
console.log(result);