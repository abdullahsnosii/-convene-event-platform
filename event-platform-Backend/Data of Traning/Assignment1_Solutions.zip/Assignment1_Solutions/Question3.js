/*
===================================================================================================
Name        : Question3.js
Author      : Edges For Training
Description : Program to convert temperatures from Celsius to Fahrenheit
===================================================================================================
*/

// Set Celsius temperature
let celsius = 60;

// Convert to Fahrenheit
let fahrenheit = (celsius * 9/5) + 32;

// Print the result
console.log(celsius + "°C is equal to " + fahrenheit + "°F");