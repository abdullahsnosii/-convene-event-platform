/*
===================================================================================================
Name        : Question8.js
Author      : Edges For Training
Description : Program that computes the factorial of a number
===================================================================================================
*/

let n = 5;
let factorial = 1;

for (let i = 2; i <= n; i++) {
    factorial *= i;
}

console.log("Factorial of", n, "is:", factorial);