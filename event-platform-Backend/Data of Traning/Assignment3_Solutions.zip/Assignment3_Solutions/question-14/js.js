/*
 ============================================================================
 Name        : Question14
 Copyright   : Edges For Training
 Description : Add and remove a class 
 ============================================================================
 */

const myDiv = document.getElementById("myDiv");
myDiv.classList.add("dark");
myDiv.classList.remove("light");
