/*
 ============================================================================
 Name        : Question10
 Copyright   : Edges For Training
 Description : Select an element by id
 ============================================================================
 */

let element = document.getElementById("myElement");

console.log("Element : ", element);
