/*
 ============================================================================
 Name        : Question1
 Copyright   : Edges For Training
 Description : What is a Promise
 ============================================================================
 */

let someThingHappend = true;
let promise = new Promise((resolve, reject) => {
  // Asynchronous code here
  if (someThingHappend) {
    resolve("Resolved");
  } else {
    reject("Rejected");
  }
});
