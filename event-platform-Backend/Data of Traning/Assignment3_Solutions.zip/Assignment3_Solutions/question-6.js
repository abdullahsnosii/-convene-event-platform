/*
 ============================================================================
 Name        : Question6
 Copyright   : Edges For Training
 Description : Async function that waits for a Promise to resolve
 ============================================================================
 */

async function getData() {
  let promise = new Promise((resolve) => {
    setTimeout(() => resolve("Data received"), 1000);
  });
  let result = await promise;
  console.log(result); // 'Data received'
}
getData();
