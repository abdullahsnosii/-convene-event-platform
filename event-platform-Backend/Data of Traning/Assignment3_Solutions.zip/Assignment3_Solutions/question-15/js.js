/*
 ============================================================================
 Name        : Question15
 Copyright   : Edges For Training
 Description : Attach event listeners 
 ============================================================================
 */

const myBtn = document.getElementById("myBtn");

myBtn.addEventListener("click", () => {
  console.log("Button clicked");
});

myBtn.addEventListener("mouseover", () => {
  console.log("Hovered");
});

myBtn.addEventListener("dblclick", () => {
  console.log("Pressed double click");
});
