/*
 ============================================================================
 Name        : Question11
 Copyright   : Edges For Training
 Description : Select elements by classname
 ============================================================================
 */

let elements = document.getElementsByClassName("myClass");

console.log("Elements : ", elements);
