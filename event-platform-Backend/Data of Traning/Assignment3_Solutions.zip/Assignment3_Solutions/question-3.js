/*
 ============================================================================
 Name        : Question3
 Copyright   : Edges For Training
 Description : Create a promise that resolves after 2 seconds
 ============================================================================
 */

let promise = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Resolved");
  }, 2000);
});

promise.then((res) => {
  console.log("Response : ", res);
});
