/*
 ============================================================================
 Name        : Question4
 Copyright   : Edges For Training
 Description : What is async and how do you define an async function?
 ============================================================================
 */

async function fetchData() {
  return "Data received";
}
fetchData().then((result) => console.log(result)); // 'Data received'
