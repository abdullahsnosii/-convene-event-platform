/*
 ============================================================================
 Name        : Question9
 Copyright   : Edges For Training
 Description : Resolve multiple promises sequentially
 ============================================================================
 */

const promise1 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Resolved 1");
  }, 1000);
});

const promise2 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Resolved 2");
  }, 2000); // Note: The 2 seconds delay counter starts at the beginning of the promise definition, not after the first promise is resolved
});

promise1
  .then((res) => {
    console.log(res);
    return promise2;
  })
  .then((res) => {
    console.log(res);
  });
