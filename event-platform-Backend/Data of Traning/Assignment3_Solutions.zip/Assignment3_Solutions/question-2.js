/*
 ============================================================================
 Name        : Question2
 Copyright   : Edges For Training
 Description : How do you handle a resolved or rejected Promise
 ============================================================================
 */

let someThingHappend = true;
let promise = new Promise((resolve, reject) => {
  // Asynchronous code here
  if (someThingHappend) {
    resolve("Resolved");
  } else {
    reject("Rejected");
  }
});

promise
  .then((res) => {
    console.log("Response : ", res);
  })
  .catch((err) => {
    console.log("Error : ", err);
  });
