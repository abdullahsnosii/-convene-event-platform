/*
 ============================================================================
 Name        : Question5
 Copyright   : Edges For Training
 Description : What is await and how is it used inside an async function? 
 ============================================================================
 */

async function getNumber() {
  let result = await new Promise((resolve) => resolve(42));
  console.log(result); // 42
}
getNumber();
