/*
 ============================================================================
 Name        : Question13
 Copyright   : Edges For Training
 Description : Change content of an already existing element
 ============================================================================
 */

let paragraph = document.getElementById("myParagraph");
paragraph.innerHTML = "New content"; // Changes the HTML content
