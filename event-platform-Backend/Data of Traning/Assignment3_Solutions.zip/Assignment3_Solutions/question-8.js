/*
 ============================================================================
 Name        : Question8
 Copyright   : Edges For Training
 Description : Resolve multiple promises concurrently
 ============================================================================
 */

async function fetchAllData() {
  let promise1 = Promise.resolve("First");
  let promise2 = Promise.resolve("Second");
  let results = await Promise.all([promise1, promise2]);
  console.log(results); // ['First', 'Second']
}
fetchAllData();
