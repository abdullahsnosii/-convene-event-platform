/*
 ============================================================================
 Name        : Question12
 Copyright   : Edges For Training
 Description : Create a new element
 ============================================================================
 */

let parentDiv = document.getElementById("parent");
let newDiv = document.createElement("div");
newDiv.textContent = "Hello World";
parentDiv.appendChild(newDiv);
