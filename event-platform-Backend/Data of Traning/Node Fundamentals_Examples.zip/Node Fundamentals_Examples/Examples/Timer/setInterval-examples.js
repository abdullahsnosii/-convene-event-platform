/**
 * Exercise: setInterval usage
 *
 * This exercise demonstrates the behavior of setInterval in Node.js.
 * - Observe how setInterval schedules repeated execution of a callback at a specified interval.
 * - Notice how arguments can be passed to setInterval.
 * - Experiment with clearing intervals to stop repeated execution.
 */
console.log('--- setInterval examples start ---');

// Example 1: Counting interval with auto-clear
// This interval counts up every 250ms and stops itself after 4 ticks.
let c1 = 0;
const i1 = setInterval(() => {
  c1 += 1;
  console.log(`i1: Tick #${c1} (every 250ms)`);
  if (c1 >= 4) {
    clearInterval(i1);
    console.log('i1: Interval cleared after 4 ticks');
  }
}, 250);

// Example 2: Passing arguments to interval callback
// Demonstrates how to pass custom arguments to the callback function.
let c2 = 0;
const i2 = setInterval((label) => {
  c2 += 1;
  console.log(`i2: ${label} - Tick #${c2} (every 300ms)`);
  if (c2 >= 2) {
    clearInterval(i2);
    console.log('i2: Interval cleared after 2 ticks');
  }
}, 300, 'CustomLabel');

// Example 3: Very short interval and manual clear
// Shows how to manually clear an interval after a set time.
const i3 = setInterval(() => console.log('i3: Fast tick (every 50ms)'), 50);
setTimeout(() => {
  clearInterval(i3);
  console.log('i3: Interval cleared after ~200ms');
}, 200);

setTimeout(() => console.log('--- setInterval examples end ---'), 1250);
