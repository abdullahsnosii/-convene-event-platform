/**
 * Exercise: setImmediate vs setTimeout(0)
 *
 * Goals for students:
 * - Observe the order of execution for `setImmediate` and `setTimeout(..., 0)`.
 * - See how context (main execution vs I/O callback) affects ordering.
 * - Learn how to pass arguments to `setImmediate`.
 */

console.log('--- setImmediate examples start ---');

// Example 1: Basic setImmediate usage
// Schedules a callback to run on the check phase (after I/O callbacks).
setImmediate(() => console.log('imm1: Basic setImmediate ran (check phase)'));

// Example 2: Passing arguments to setImmediate
// The callback receives the provided argument(s) when it runs.
setImmediate((who) => console.log(`imm2: Ran for ${who}`), 'Bob');

// Example 3: setImmediate vs setTimeout(..., 0) from main turn
// When scheduled from the main turn, the ordering between setImmediate and
// setTimeout(..., 0) is not strictly guaranteed across environments —
// run this multiple times to observe behavior and note differences.
setImmediate(() => console.log('imm3: setImmediate scheduled from main turn'));
setTimeout(() => console.log('timeout0: setTimeout(0) scheduled from main turn'), 0);

// Example 4: Scheduling inside an I/O callback (deterministic ordering)
// When scheduled inside an I/O callback, setImmediate will usually run
// before setTimeout(..., 0). This demonstrates phase ordering in Node's
// event loop (I/O callbacks -> check phase -> timers).
const fs = require('fs');
fs.readFile(__filename, 'utf8', () => {
  setImmediate(() => console.log('imm4: setImmediate from I/O callback (typically first)'));
  setTimeout(() => console.log('timeout0-from-IO: setTimeout(0) from I/O callback (typically after setImmediate)'), 0);
  console.log('imm4: inside I/O callback (synchronous log)');
});

// End marker: give enough time for all examples to run
setTimeout(() => console.log('--- setImmediate examples end ---'), 800);
