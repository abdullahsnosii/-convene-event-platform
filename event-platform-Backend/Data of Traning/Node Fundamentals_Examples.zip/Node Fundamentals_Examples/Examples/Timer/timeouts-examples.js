/**
 * Exercise: timeouts and intervals
 *
 * Goals for students:
 * - See practical uses of `setTimeout`, `setInterval`, and `setImmediate`.
 * - Learn how to cancel timers and why that's useful.
 * - Observe deterministic ordering when scheduling inside I/O callbacks.
 */

console.log('--- timers examples start ---');

// 1) setTimeout: run once after a delay
// Schedules a callback to run after 1000ms with a message argument.
const timeoutId = setTimeout((msg) => {
  console.log('setTimeout fired:', msg);
}, 1000, 'hello from setTimeout');

// We can cancel a scheduled timeout before it runs
const timeoutToCancel = setTimeout(() => {
  console.log('This should NOT appear (timeout cancelled)');
}, 500);
clearTimeout(timeoutToCancel);

// 2) setInterval: run repeatedly until cleared
// Runs every 400ms; stops after 3 ticks to avoid runaway intervals in examples.
let count = 0;
const intervalId = setInterval((label) => {
  count += 1;
  console.log(`setInterval (${label}) tick #${count}`);
  if (count >= 3) {
    clearInterval(intervalId);
    console.log('setInterval cleared after 3 ticks');
  }
}, 400, 'repeating');

// 3) setImmediate: runs on the next event-loop turn (check phase)
setImmediate(() => {
  console.log('setImmediate callback ran (check phase)');
});

// Compare with setTimeout(..., 0): zero-delay timer
setTimeout(() => {
  console.log('setTimeout 0 callback ran (timers phase)');
}, 0);

// 4) clearImmediate example: schedule and cancel immediately
const imm = setImmediate(() => {
  console.log('This setImmediate will be cleared and should NOT run');
});
clearImmediate(imm);

// 5) Deterministic ordering example using a small I/O operation
// When scheduled inside an I/O callback, setImmediate typically runs
// before setTimeout(..., 0). This demonstrates Node's event loop phases.
const fs = require('fs');
fs.readFile(__filename, 'utf8', () => {
  setImmediate(() => console.log('inside I/O: setImmediate ran (usually first)'));
  setTimeout(() => console.log('inside I/O: setTimeout(0) ran (usually after setImmediate)'), 0);
});

// Cleanup: ensure long-running timers are cleared after the demo
setTimeout(() => {
  clearTimeout(timeoutId);
  clearInterval(intervalId);
  console.log('--- timers examples end (cleanup) ---');
}, 3000);
