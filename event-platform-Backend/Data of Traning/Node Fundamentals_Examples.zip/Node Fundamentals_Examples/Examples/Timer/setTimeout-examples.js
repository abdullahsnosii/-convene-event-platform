/**
 * Exercise: setTimeout usage
 *
 * Goals for students:
 * - Observe how `setTimeout` schedules callbacks after specified delays.
 * - Learn how to pass arguments and how to cancel scheduled timeouts.
 */

console.log('--- setTimeout examples start ---');

// Example 1: Delayed execution with an argument
// Schedules a callback to run after 500ms, passing 'Alice' as an argument.
const t1 = setTimeout((who) => {
  console.log(`t1: Fired for ${who} after 500ms`);
}, 500, 'Alice');

// Example 2: Zero-delay scheduling
// Schedules a callback to run as soon as possible after the current event loop turn.
setTimeout(() => console.log('t2: setTimeout 0 ran (zero delay)'), 0);

// Example 3: Multiple delays to demonstrate relative ordering
setTimeout(() => console.log('t3: Fired after 100ms'), 100);
setTimeout(() => console.log('t4: Fired after 200ms'), 200);

// Example 4: Canceling a scheduled timeout
// Schedule a callback but cancel it before it runs.
const willBeCleared = setTimeout(() => console.log('t5: This should NOT appear (timeout canceled)'), 1000);
clearTimeout(willBeCleared);

// End marker: allow enough time for all examples to complete
setTimeout(() => console.log('--- setTimeout examples end ---'), 1200);
