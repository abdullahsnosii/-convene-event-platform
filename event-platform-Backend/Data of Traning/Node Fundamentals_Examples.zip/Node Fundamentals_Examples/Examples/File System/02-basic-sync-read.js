/*
Exercise 01 - Basic synchronous read

Goal:
  Read the content of a file synchronously and print it to stdout. This exercise
  teaches the simplest synchronous usage of Node's `fs` module.

Details:
  - Use the environment variable `TARGET_FILE` to locate the file. If not set,
    the script should default to a `data.txt` file in the same folder.
  - Read using `fs.readFileSync(path, { encoding: 'utf8' })` and `console.log` the
    content. Handle errors by printing a helpful message and returning a non-zero
    exit code.

Why it matters:
  Synchronous APIs are blocking; they're easy to understand and useful for
  small scripts, but they block the event loop and shouldn't be used in high-
  traffic servers.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

try {
  const content = fs.readFileSync(target, { encoding: 'utf8' });
  console.log(content);
} catch (err) {
  console.error('Error reading file:', err.message);
  process.exitCode = 1;
}
  console.log('File read successfully');
