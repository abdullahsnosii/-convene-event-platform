console.log("Example of dirname")
console.log(__dirname);
console.log("\n Example of filename ")
console.log(__filename);