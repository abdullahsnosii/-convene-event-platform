/*
Exercise 02 - Basic synchronous write

Goal:
  Write a string to a file synchronously. Learn the synchronous writing API
  and how to set default behavior with environment variables.

Details:
  - Read `TARGET_FILE` from env (defaults to `data.txt`). Use `TEXT` env var
    as the string to write (default: 'Hello filesystem').
  - Use `fs.writeFileSync(path, text, { encoding: 'utf8' })` and print a
    confirmation message on success.

Why it matters:
  Synchronous writes are simple but block the event loop. They are fine for
  small CLI tools or setup scripts.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

const text = 'Hello filesystem';

try {
  fs.writeFileSync(target, text, { encoding: 'utf8' });
  console.log('Wrote file');
} catch (err) {
  console.error('Error writing file:', err.message);
  process.exitCode = 1;
}
console.log('File write operation completed');