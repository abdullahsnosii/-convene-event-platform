/*
Exercise 09 - Async read/write with promises

Goal:
  Use the `fs.promises` API for cleaner async code with `async/await`.

Details:
  - Use `TARGET_FILE` env var. Use `fs.promises.writeFile` and
    `fs.promises.readFile` with `await`.
  - Print the content of the file after writing.

Why it matters:
  Promises and `async/await` simplify async control flow and are the
  recommended modern approach for file IO.
*/
const fs = require('fs').promises;
const path = require('path');
const target = path.join(__dirname, 'data.txt');

(async () => {
  try {
    await fs.writeFile(target, 'written with promises', { encoding: 'utf8' });
    const content = await fs.readFile(target, 'utf8');
    console.log('Read after write (promises):', content);
  } catch (err) {
    console.error('Error (promises):', err.message);
    process.exitCode = 1;
  }
})();
