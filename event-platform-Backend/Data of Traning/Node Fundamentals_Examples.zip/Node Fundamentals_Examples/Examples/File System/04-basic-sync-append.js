/*
Exercise 03 - Basic synchronous append

Goal:
  Append text to an existing file synchronously. This demonstrates how to
  update files without overwriting them.

Details:
  - Use `TARGET_FILE` (default `data.txt`) and `TEXT` (default '\nAppended line').
  - Use `fs.appendFileSync(path, text, { encoding: 'utf8' })`.

Why it matters:
  Appending is common for logs and simple persistence. With synchronous
  operations you must be aware of blocking behavior.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

const text = '\nAppended line';

try {
  fs.appendFileSync(target, text, { encoding: 'utf8' });
  console.log('Appended to file');
} catch (err) {
  console.error('Error appending file:', err.message);
  process.exitCode = 1;
}
