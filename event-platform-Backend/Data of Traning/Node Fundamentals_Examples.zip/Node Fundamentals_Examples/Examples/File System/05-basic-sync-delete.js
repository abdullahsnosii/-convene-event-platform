/*
Exercise 04 - Basic synchronous delete

Goal:
  Delete a file synchronously if it exists. Learn how to check file existence
  and remove files safely.

Details:
  - Use `TARGET_FILE` (default `data.txt`). If the file exists use
    `fs.unlinkSync(path)` to delete it. Otherwise, print a friendly message.

Why it matters:
  Deleting files is an important cleanup operation; handle missing files and
  permissions errors gracefully.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

try {
  if (fs.existsSync(target)) {
    fs.unlinkSync(target);
    console.log('Deleted file');
  } else {
    console.log('File does not exist');
  }
} catch (err) {
  console.error('Error deleting file:', err.message);
  process.exitCode = 1;
}
