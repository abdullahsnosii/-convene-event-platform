/*
Exercise 05 - Async read with callbacks

Goal:
  Read a file using the asynchronous callback-style API. Understand the
  non-blocking model and error-first callback pattern.

Details:
  - Use `TARGET_FILE` (default `data.txt`). Call `fs.readFile(path, {encoding:'utf8'}, callback)`.
  - In the callback, check `err` first and handle it, otherwise print `data`.

Why it matters:
  Callback-style async is the foundation of Node's event-driven design; it
  teaches how to avoid blocking the event loop.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

fs.readFile(target, { encoding: 'utf8' }, (err, data) => {
  if (err) {
    console.error('Error reading file:', err.message);
    process.exitCode = 1;
    return;
  }
  console.log(data);
});
console.log('File read successfully');
