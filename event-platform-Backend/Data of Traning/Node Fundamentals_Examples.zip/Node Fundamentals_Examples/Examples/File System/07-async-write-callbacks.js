/*
Exercise 06 - Async write with callbacks

Goal:
  Write a file asynchronously using the callback API. Learn to handle
  completion in a callback instead of assuming synchronous completion.

Details:
  - Use `TARGET_FILE` and `TEXT` env vars. Use `fs.writeFile(path, data, options, callback)`.
  - In the callback, detect errors and print success when done.

Why it matters:
  Async writes avoid blocking; callbacks allow you to act after the operation
  completes.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');
const text = 'Async write';

fs.writeFile(target, text, { encoding: 'utf8' }, (err) => {
  if (err) {
    console.error('Error writing file:', err.message);
    process.exitCode = 1;
    return;
  }
  console.log('Wrote file (async)');
});

console.log('File write operation initiated (async)');