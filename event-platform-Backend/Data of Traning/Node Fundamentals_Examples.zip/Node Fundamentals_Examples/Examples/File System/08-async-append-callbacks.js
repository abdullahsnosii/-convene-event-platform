/*
Exercise 07 - Async append with callbacks

Goal:
  Append to a file using the async callback API. Practice updating files
  without blocking.

Details:
  - Use `TARGET_FILE` and `TEXT` env vars. Use `fs.appendFile(path, data, options, callback)`.
  - Handle errors in the callback and confirm success.

Why it matters:
  Appending asynchronously is common for logging; it keeps your app
  responsive while IO happens.
*/
const fs = require('fs');
const path = require('path');
const target =  path.join(__dirname, 'data.txt');
const text = '\nAsync append';

fs.appendFile(target, text, { encoding: 'utf8' }, (err) => {
  if (err) {
    console.error('Error appending file:', err.message);
    process.exitCode = 1;
    return;
  }
  console.log('Appended file (async)');
});
