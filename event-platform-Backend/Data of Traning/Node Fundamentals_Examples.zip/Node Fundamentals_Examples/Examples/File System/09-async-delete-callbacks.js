/*
Exercise 08 - Async delete with callbacks

Goal:
  Delete a file asynchronously and learn to handle the ENOENT case gracefully.

Details:
  - Use `TARGET_FILE` env var. Call `fs.unlink(path, callback)`.
  - If the callback receives an error, check `err.code` for `ENOENT` and
    treat it as a non-fatal condition (file already gone).

Why it matters:
  Correct error handling in async callbacks is essential for robust IO code.
*/
const fs = require('fs');
const path = require('path');
const target = path.join(__dirname, 'data.txt');

fs.unlink(target, (err) => {
  if (err) {
    if (err.code === 'ENOENT') {
      console.log('File not found');
      return;
    }
    console.error('Error deleting file:', err.message);
    process.exitCode = 1;
    return;
  }
  console.log('Deleted file (async)');
});
