# Node process examples (.env)

Files in this folder demonstrate how to use the Node `process` object and load environment variables from a `.env` file.

Files:
- `process-env.js` — inspect `process.env` and safe conversions.
- `.env` — example environment file (already present).

Quick start:
1. Install dependencies (runs in PowerShell or any shell):
```
npm install
```

2. Run the examples:
```
npm run env
```

