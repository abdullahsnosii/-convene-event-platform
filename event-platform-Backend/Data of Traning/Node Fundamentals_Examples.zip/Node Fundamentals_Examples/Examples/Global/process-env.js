/**
 * Exercise: Inspect environment variables with `process.env`
 *
 * Goals for students:
 * - Learn how to read environment variables from `process.env`.
 * - Provide safe defaults and convert values (e.g., PORT) to numbers.
 *
 * Examples:
 *   NODE_ENV=production 
 *   MY_VAR=42 
 */
require('dotenv').config();
console.log('All process.env keys (first 20 shown):');
Object.keys(process.env).slice(0, 20).forEach((k) => console.log(k));

// Access specific variables with defaults
const nodeEnv = process.env.NODE_ENV || 'development';
const pathVar = process.env.PATH || process.env.Path || '<no PATH available>';
const custom = process.env.MY_VAR || '<not set>';

console.log('\nNODE_ENV:', nodeEnv);
console.log('PATH (truncated):', pathVar.slice(0, 120) + (pathVar.length > 120 ? '...' : ''));
console.log('MY_VAR:', custom);

// Safe usage: convert numeric env vars
const port = Number(process.env.PORT || 0);
if (Number.isFinite(port) && port > 0) {
  console.log('PORT is a valid number:', port);
} else {
  console.log('PORT not set or invalid.');
}
