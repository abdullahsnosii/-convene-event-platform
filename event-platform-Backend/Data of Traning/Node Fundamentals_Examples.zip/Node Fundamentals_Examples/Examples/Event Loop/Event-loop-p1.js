const fs = require('fs');
const crypto = require('crypto');
const dns = require('dns');
const net = require('net');

console.log('🔵 1. Top-level start');

// ----- Timers -----
setTimeout(() => {
  console.log('🟢 Timers Phase: setTimeout 0ms');
}, 0);

// ----- Microtasks -----
process.nextTick(() => {
  console.log('🟣 Microtask: process.nextTick');
});

Promise.resolve().then(() => {
  console.log('🟣 Microtask: Promise.then');
});

// ----- Pending Callbacks -----
dns.lookup('google.com', () => {
  console.log('🟡 Pending Callbacks Phase: DNS lookup callback');
});

// ----- Poll -----
fs.readFile(__filename, () => {
  console.log('🟠 Poll Phase: fs.readFile callback');
});

// ----- Check -----
setImmediate(() => {
  console.log('🔴 Check Phase: setImmediate callback');
});

// ----- Server and Close Callbacks -----
const server = net.createServer((socket) => {
  // Simulate active connection, close after 50ms
  setTimeout(() => {
    socket.end();
  }, 50);
});

server.on('close', () => {
  console.log('⚫ Close Callbacks Phase: server close event');
});

server.listen(0, () => {
  // Make an active connection
  const client = net.connect(
    { port: server.address().port },
    () => {
      console.log('⚪ Active connection established');

      // Close the server only after the client connects
      server.close();
    }
  );
});

// ----- Worker Thread Pool -----
crypto.pbkdf2(
  'password',
  'salt',
  100000,
  64,
  'sha512',
  () => {
    console.log('⚙️ Worker Thread: crypto.pbkdf2 finished');
  }
);

console.log('🔵 2. Top-level end');