// ============================================================
// Forcing the event loop to run phases in TEXTBOOK order:
// 1 Timers → 2 Pending Callbacks → 3 Poll → 4 Check → 5 Close
//
// THE TWO RULES THAT MAKE THIS WORK:
//
// RULE 1 — Register all callbacks during the initial
//          synchronous run (tick 0), so they all compete
//          to be queued into the SAME iteration's phases.
//
// RULE 2 — For "close", DON'T call .close() from something
//          that resolves instantly via process.nextTick
//          (like the 'listening' event — that races ahead
//          of the whole iteration). Instead, call .close()
//          from INSIDE a later-phase callback (here: the
//          check-phase setImmediate) that itself was
//          registered at tick 0. Then its close-callback
//          gets queued into THIS SAME iteration's close
//          phase — which is the final phase, so it runs last.
// ============================================================

const fs = require('fs');
const net = require('net');

console.log('=== start ===\n');

const server = net.createServer();
server.listen(0); // no callback here — avoids the nextTick race

// [1] TIMERS — registered at tick 0
setTimeout(() => {
  console.log('[1] TIMERS PHASE');
}, 0);

// [2] PENDING CALLBACKS — registered at tick 0
const badSocket = net.connect(9999, '127.0.0.1');
badSocket.on('error', () => {
  console.log('[2] PENDING CALLBACKS PHASE');
});

// [3] POLL — registered at tick 0
fs.readFile(__filename, () => {
  console.log('[3] POLL PHASE');

  // [4] CHECK — registered from inside poll (same iteration, next phase)
  setImmediate(() => {
    console.log('[4] CHECK PHASE');

    // [5] CLOSE — triggered HERE (during check phase of THIS
    // iteration), so its close-callback queues into the close
    // phase of THIS SAME iteration → runs last.
    server.close(() => {
      console.log('[5] CLOSE CALLBACKS PHASE');
    });
  });
});

console.log('=== end (sync code) ===');

// ============================================================
// ACTUAL OUTPUT (captured from a real run):
//
// === start ===
//
// === end (sync code) ===
// [1] TIMERS PHASE
// [2] PENDING CALLBACKS PHASE
// [3] POLL PHASE
// [4] CHECK PHASE
// [5] CLOSE CALLBACKS PHASE
//
// Clean 1 → 2 → 3 → 4 → 5 order — exactly the textbook diagram!
// ============================================================