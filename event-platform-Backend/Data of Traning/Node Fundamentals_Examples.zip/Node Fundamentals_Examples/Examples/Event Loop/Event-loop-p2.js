// ============================================================
// PART 2: Close phase running LAST (as the textbook diagram
// shows) — the trick is to trigger close() FROM INSIDE a
// later-phase callback, so its close-callback gets queued
// into THIS iteration's close phase, which is the final
// phase of the iteration.
// ============================================================
 const fs = require('fs');
const net = require('net');

console.log('\n=== PART 2: forcing close to run AFTER 1,3,4 ===\n');
 
const server2 = net.createServer();
server2.listen(0, () => {
 
  // Phase 1: Timers
  setTimeout(() => {
    console.log('[1] TIMERS PHASE (part2)');
  }, 0);
 
  // Phase 3: Poll
  fs.readFile(__filename, () => {
    console.log('[3] POLL PHASE  (part2)');
 
    // Phase 4: Check
    setImmediate(() => {
      console.log('[4] CHECK PHASE (part2)');
 
      // Closing HERE means the close callback is queued into
      // THIS iteration's close phase — which only runs after
      // phase 4 (check) of this same iteration is done.
      server2.close(() => {
        console.log('[5] CLOSE CALLBACKS (part2) → runs LAST, as expected');
      });
    });
  });
});
 
 
// ============================================================
// LESSON: the 5-phase ORDER (timers → pending → poll → check
// → close) is fixed per iteration. But WHERE in your code you
// call something (and therefore WHICH iteration / WHICH point
// in that iteration its callback gets queued) determines
// whether it appears "first" or "last" in your output.
// Code order ≠ execution order.

// The event loop phase order (Timers → Pending → Poll →
// Check → Close) is fixed within each iteration.

// However, callbacks from different asynchronous operations
// may belong to different iterations. Therefore, the overall
// output depends on both the phase order and the iteration
//   in which each callback becomes ready.
// ============================================================
