const fs = require('fs')

console.log('A: start')

setTimeout(() => console.log('B: setTimeout'), 0)

fs.readFile(__filename, () => {
    console.log('C: fs.readFile')
})

Promise.resolve().then(() => console.log('D: promise'))

process.nextTick(() => console.log('E: nextTick'))

setImmediate(() => console.log('F: setImmediate'))

console.log('G: end')