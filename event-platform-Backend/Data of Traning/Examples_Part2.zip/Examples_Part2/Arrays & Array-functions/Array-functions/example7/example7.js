/*
 ============================================================================
 Name        : Example7
 Copyright   : Edges For Training
 Description : Finding maximum value
 ============================================================================
 */

const numbers = [10, 5, 8, 20, 3];

const maxNumber = numbers.reduce(
  (max, current) => (current > max ? current : max),
  numbers[0]
);

console.log("Maximum Number:", maxNumber); // 20
