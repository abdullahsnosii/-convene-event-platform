/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Adding status property
 ============================================================================
 */

const students = [
  { name: "Ali", score: 80 },
  { name: "Lina", score: 90 },
  { name: "Kareem", score: 85 },
];

// Adding a "status" property based on score
const studentsWithStatus = students.map((student) => ({
  ...student, // Keep existing properties
  status: student.score >= 85 ? "Passed" : "Failed",
}));

console.log(studentsWithStatus);
