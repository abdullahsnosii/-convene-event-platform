/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Using forEach to Loop Through an Array
 ============================================================================
 */

// Define an array of students
const students = ["Ahmed", "Sara", "Omar", "Mona"];

// Using forEach to print each student's name
students.forEach(function (student, index, array) {
  console.log(`Student ${index + 1}: ${student}`);
});
