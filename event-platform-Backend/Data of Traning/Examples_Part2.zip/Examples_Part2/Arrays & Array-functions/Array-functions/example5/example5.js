/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : Filtering even numberss
 ============================================================================
 */

const numbers = [1, 2, 3, 4, 5, 6];

// Using filter() to get even numbers
const evenNumbers = numbers.filter((num) => num % 2 === 0);

console.log("Original Array:", numbers); // [1, 2, 3, 4, 5, 6]
console.log("Even Numbers:", evenNumbers); // [2, 4, 6]
