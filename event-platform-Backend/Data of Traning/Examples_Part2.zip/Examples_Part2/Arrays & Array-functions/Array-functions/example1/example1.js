/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Using push, pop, shift, and unshift
 ============================================================================
 */

// Initial array
let numbers = [1, 2, 3];

console.log("Initial Array:", numbers);

// 👉 push() - Adds an element to the END of the array
numbers.push(4);
console.log("After push(4):", numbers); // [1, 2, 3, 4]

// 👉 pop() - Removes the LAST element from the array
let popped = numbers.pop();
console.log("After pop():", numbers); // [1, 2, 3]
console.log("Popped Element:", popped); // 4

// 👉 unshift() - Adds an element to the BEGINNING of the array
numbers.unshift(0);
console.log("After unshift(0):", numbers); // [0, 1, 2, 3]

// 👉 shift() - Removes the FIRST element from the array
let shifted = numbers.shift();
console.log("After shift():", numbers); // [1, 2, 3]
console.log("Shifted Element:", shifted); // 0
