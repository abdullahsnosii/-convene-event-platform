/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Doubling numbers
 ============================================================================
 */

const numbers = [1, 2, 3, 4];

// Using map() to create a new array with doubled values
const doubledNumbers = numbers.map((num) => num * 2);

console.log("Original Array:", numbers); // [1, 2, 3, 4]
console.log("Doubled Array:", doubledNumbers); // [2, 4, 6, 8]
