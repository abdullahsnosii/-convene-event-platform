/*
 ============================================================================
 Name        : Example6
 Copyright   : Edges For Training
 Description : Accumlate numbers
 ============================================================================
 */

const numbers = [1, 2, 3, 4, 5];

// Using reduce() to sum all numbers
const sum = numbers.reduce((accumulator, current) => accumulator + current, 0);

console.log("Sum of Numbers:", sum); // 15
