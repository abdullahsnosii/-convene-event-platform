/*
 ============================================================================
 Name        : Example8
 Copyright   : Edges For Training
 Description : Analyzing a List of Students
 ============================================================================
 */

const students = [
  { name: "Ali", score: 45 },
  { name: "Lina", score: 78 },
  { name: "Kareem", score: 90 },
  { name: "Sara", score: 38 },
  { name: "Omar", score: 55 },
];

// 1️⃣ Filter students who passed
const passedStudents = students.filter((student) => student.score >= 50);

// 2️⃣ Map names to uppercase
const formattedNames = passedStudents.map((student) =>
  student.name.toUpperCase()
);

// 3️⃣ Calculate the average score using reduce
const totalScore = passedStudents.reduce(
  (sum, student) => sum + student.score,
  0
);
const averageScore = totalScore / passedStudents.length;

// 4️⃣ Log the final list of students using forEach
console.log("✅ Passed Students:");
passedStudents.forEach((student) => {
  console.log(`- ${student.name} (Score: ${student.score})`);
});

console.log("\n🔹 Uppercase Names:", formattedNames);
console.log("📊 Average Score:", averageScore.toFixed(2));
