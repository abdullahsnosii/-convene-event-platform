/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : For...of
 ============================================================================
 */

const animals = ["Cat", "Dog", "Elephant"];

console.log("Using for...of loop:");
for (let animal of animals) {
  console.log("Animal:", animal);
}
