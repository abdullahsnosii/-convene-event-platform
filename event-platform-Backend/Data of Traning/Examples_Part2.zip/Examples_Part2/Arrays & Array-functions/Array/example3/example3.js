/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : For...in
 ============================================================================
 */

const fruits = ["Apple", "Banana", "Cherry"];

console.log("Using for...in loop:");
for (let index in fruits) {
  console.log(`Index ${index}: ${fruits[index]}`);
}
