/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Adding/deleting in an array
 ============================================================================
 */

// Define an empty array
const numbers = [];

// Adding elements manually
numbers[0] = 10;
numbers[1] = 20;
numbers[2] = 30;

console.log("Array after adding elements:", numbers); // [10, 20, 30]

// Deleting an element (without shifting)
delete numbers[1]; // Removes the second element but keeps an empty slot

console.log("Array after deleting an element:", numbers); // [10, empty, 30]
console.log("Check deleted index:", numbers[1]); // undefined
