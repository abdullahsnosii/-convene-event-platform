/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Accessing array elements
 ============================================================================
 */

// Define an array of colors
const colors = ["Red", "Green", "Blue"];

// Accessing elements
console.log("First color:", colors[0]); // Red
console.log("Second color:", colors[1]); // Green
console.log("Third color:", colors[2]); // Blue

// Accessing an out-of-bounds index
console.log("Non-existent color:", colors[5]); // undefined
