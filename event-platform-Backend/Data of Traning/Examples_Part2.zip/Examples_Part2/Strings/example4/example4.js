/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Slicing a string
 ============================================================================
 */

let sentence = "Programming is fun!";
console.log(sentence.slice(0, 11)); // Output: "Programming"
