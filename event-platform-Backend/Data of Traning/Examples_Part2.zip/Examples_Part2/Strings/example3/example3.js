/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Replacing text
 ============================================================================
 */

let greeting = "Good morning!";
console.log(greeting.replace("morning", "evening")); // Output: "Good evening!"
