/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Changing Case (toUpperCase() and toLowerCase())
 ============================================================================
 */

let message = "JavaScript";
console.log(message.toUpperCase()); // Output: "JAVASCRIPT"
console.log(message.toLowerCase()); // Output: "javascript"
