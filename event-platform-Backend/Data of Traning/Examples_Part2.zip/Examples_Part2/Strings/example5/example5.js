/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : List of Common String Methods

 ============================================================================
 */
// Basic String Methods
let str = "Hello, JavaScript!";

str.length; // Returns the length of the string
str.toUpperCase(); // Converts to uppercase
str.toLowerCase(); // Converts to lowercase
str.charAt(0); // Returns the character at a specific index
str.indexOf("J"); // Finds the position of a character or word
str.includes("Java"); // Checks if a string contains a word
str.startsWith("Hello"); // Checks if the string starts with a specific word
str.endsWith("!"); // Checks if the string ends with a specific character
str.slice(0, 5); // Extracts a part of the string
str.substring(0, 5); // Similar to slice, but cannot accept negative indexes, it treats them as 0
str.replace("JavaScript", "JS"); // Replaces a word
str.trim(); // Removes spaces from both sides
str.split(" "); // Splits a string into an array

// Multi-line string using template literals
let multiLine = `Hello,
This is a multi-line string in JavaScript.`;

// String Concatenation
let name = "Alice";
let greeting = "Hello, " + name + "!"; // Using +
let greeting2 = `Hello, ${name}!`; // Using template literals
