/*
 ============================================================================
 Name        : Example6
 Copyright   : Edges For Training
 Description : Checking validity of a coupon 
 ============================================================================
 */

let coupon = "DISCOUNT10";
let userInput = "discount10";

if (coupon.toLowerCase() === userInput.toLowerCase()) {
  console.log("Coupon applied successfully!");
} else {
  console.log("Invalid coupon.");
}
