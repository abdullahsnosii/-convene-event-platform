/*
 ============================================================================
 Name        : Example7
 Copyright   : Edges For Training
 Description : Customer Support Ticket System
 ============================================================================
 */

function capitalizeName(name) {
  let firstLetter = name.charAt(0).toUpperCase();
  let restOfName = name.slice(1).toLowerCase();
  return firstLetter + restOfName;
}

function extractCompany(email) {
  let atIndex = email.indexOf("@");
  let dotIndex = email.lastIndexOf(".");
  if (atIndex !== -1 && dotIndex > atIndex) {
    return email.slice(atIndex + 1, dotIndex);
  }
  return "Unknown Company";
}

function shortenMessage(message, maxLength) {
  if (message.length > maxLength) {
    return message.slice(0, maxLength) + "...";
  }
  return message;
}

function generateTicketID(name) {
  let firstInitial = name.charAt(0).toUpperCase();
  let timestamp = new Date().getTime().toString().slice(-4);
  return "TCK" + firstInitial + timestamp;
}

function submitTicket(fullName, email, message) {
  let formattedName = capitalizeName(fullName);
  let company = extractCompany(email);
  let shortMessage = shortenMessage(message, 50);
  let ticketID = generateTicketID(formattedName);

  let confirmationMessage = "Support Ticket Created!\n";
  confirmationMessage += "Ticket ID: " + ticketID + "\n";
  confirmationMessage += "Customer: " + formattedName + "\n";
  confirmationMessage += "Company: " + company + "\n";
  confirmationMessage += "Issue: " + shortMessage;

  return confirmationMessage;
}

// Example Usage
let fullName = "john doe";
let email = "john.doe@company.com";
let message =
  "My account has been locked and I need immediate assistance to regain access as soon as possible.";

console.log(submitTicket(fullName, email, message));
