/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Finding the Length of a String (length)
 ============================================================================
 */

let text = "Hello, world!";
console.log(text.length); // Output: 13
