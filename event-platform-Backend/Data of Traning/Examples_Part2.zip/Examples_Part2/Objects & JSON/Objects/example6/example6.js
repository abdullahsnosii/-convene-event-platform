/*
 ============================================================================
 Name        : Example6
 Copyright   : Edges For Training
 Description : Library Book Management
 ============================================================================
 */

const book = {
  title: "the art of programming",
  author: "John Doe",
  genre: "computer science",
  publicationYear: 2015,
  isAvailable: true,

  // Method to format the title
  formatTitle: function () {
    this.title = this.title.toUpperCase();
  },

  // Method to check if genre includes a keyword
  checkGenre: function (keyword) {
    return this.genre.includes(keyword.toLowerCase());
  },

  // Method to update the title
  updateTitle: function (oldWord, newWord) {
    this.title = this.title.replace(oldWord, newWord);
  },

  // Method to toggle availability
  toggleAvailability: function () {
    this.isAvailable = !this.isAvailable;
  },
};

// Before modifications
console.log("Original Book:", book);

// Format the title
book.formatTitle();
console.log("Formatted Title:", book.title);

// Check if genre contains 'science'
console.log("Contains 'science' in genre:", book.checkGenre("science"));

// Replace "PROGRAMMING" with "CODING"
book.updateTitle("PROGRAMMING", "CODING");
console.log("Updated Title:", book.title);

// Toggle availability
book.toggleAvailability();
console.log("Availability Toggled:", book.isAvailable);
