/*
 ============================================================================
 Name        : Example3
 Copyright   : Edges For Training
 Description : Managing a Product Inventory
 ============================================================================
 */

// Step 1: Creating the Object
let product = {
  name: "Laptop",
  price: 1200,
  stock: 50,
};
console.log("Original Product:", product);

// Step 2: Modifying an Existing Property
product.price = 1000; // Modify price
console.log("After Price Update:", product);

// Step 3: Adding a New Property
product.category = "Electronics";
console.log("After Adding Category:", product);

// Step 4: Removing a Property
delete product.stock;
console.log("After Removing Stock:", product);

// Step 5: Reference vs. Value (Objects are stored by reference)
let anotherProduct = product; // anotherProduct points to the same object
anotherProduct.price = 800; // Changing price via anotherProduct
console.log("Product After Changing anotherProduct:", product);
console.log("anotherProduct:", anotherProduct);

// Step 6: Breaking the Reference (Creating a Copy)
let productCopy = { ...product }; // New independent copy
productCopy.price = 1500; // Change only the copy
console.log("Original Product:", product);
console.log("Modified Copy:", productCopy);
