/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Object Shallow clone 
 ============================================================================
 */

 const obj = { a: 1, b: { c: 2 } };
 const shallowClone1 = { ...obj };
 const shallowClone2 = Object.assign({}, obj);
 
 shallowClone1.a = 40;
 shallowClone1.b.c = 42;
 console.log(obj.a);
 console.log(obj.b.c); // 42 (Original object affected!)