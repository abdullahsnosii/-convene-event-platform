/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Accessing an object
 ============================================================================
 */

const employee = {
  name: "Alice Johnson",
  age: 30,
  job: {
    title: "Software Engineer",
    department: "IT",
  },
  "employee-id": 12345,
  getDetails: function () {
    return `${this.name}, ${this.job.title}, Age: ${this.age}`;
  },
};

console.log(employee.name); // "Alice Johnson"
console.log(employee.age); // 30
console.log(employee.job.title); // "Software Engineer"
console.log(employee.getDetails()); // "Alice Johnson, Software Engineer, Age: 30"
// console.log(employee.employee-id); // Error

console.log(employee["name"]); // "Alice Johnson"
console.log(employee["job"]["title"]); // "Software Engineer"
console.log(employee["employee-id"]); // 12345
