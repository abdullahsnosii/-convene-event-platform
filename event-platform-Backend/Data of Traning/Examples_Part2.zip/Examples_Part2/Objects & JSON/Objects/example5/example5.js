/*
 ============================================================================
 Name        : Example5
 Copyright   : Edges For Training
 Description : Product Information
 ============================================================================
 */

const product = {
  name: "Smartphone",
  brand: "TechCo",
  price: 900,
  stock: 25,
};

// Object.keys() - Get all keys
console.log("Keys:", Object.keys(product));

// Object.values() - Get all values
console.log("Values:", Object.values(product));

// Object.entries() - Get key-value pairs
console.log("Entries:");
console.log(Object.entries(product));
Object.entries(product).forEach(([key, value]) => {
  console.log(`${key}: ${value}`);
});
