/*
 ============================================================================
 Name        : Example4
 Copyright   : Edges For Training
 Description : Employee Record
 ============================================================================
 */

const employee = {
  name: "Alice Johnson",
  age: 30,
  department: "IT",
  salary: 5000,
  isActive: true,
  getDetails: function () {
    return `${this.name}, ${this.department}, Salary: ${this.salary}`;
  },
};

// Using for...in loop to iterate over object properties
console.log("Employee Details:");
for (let key in employee) {
  // Skip functions (methods)
  if (typeof employee[key] !== "function") {
    console.log(`${key}: ${employee[key]}`);
  }
}
