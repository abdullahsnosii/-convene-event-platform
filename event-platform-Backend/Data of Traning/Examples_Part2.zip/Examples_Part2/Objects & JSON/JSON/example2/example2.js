/*
 ============================================================================
 Name        : Example2
 Copyright   : Edges For Training
 Description : Deep copy using JSON
 ============================================================================
 */

// Original object with nested properties
const original = {
  name: "Alice",
  address: {
    city: "New York",
    zip: 10001,
  },
};

// Deep copy using JSON methods
const deepCopy = JSON.parse(JSON.stringify(original));

// Modify the deep copy
deepCopy.name = "Bob";
deepCopy.address.city = "Los Angeles";

// Original object remains unchanged
console.log("Original Object:", original);
console.log("Deep Copied Object:", deepCopy);
