/*
 ============================================================================
 Name        : Example1
 Copyright   : Edges For Training
 Description : Basic JSON usage
 ============================================================================
 */

// Original JavaScript object
const user = {
  name: "John Doe",
  age: 30,
  isAdmin: true,
};

// Convert object to JSON string
const jsonString = JSON.stringify(user);
console.log("JSON String:", jsonString);

// Convert JSON string back to object
const parsedObject = JSON.parse(jsonString);
console.log("Parsed Object:", parsedObject);
