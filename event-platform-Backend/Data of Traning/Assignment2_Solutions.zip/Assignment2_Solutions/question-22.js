/*
 ============================================================================
 Name        : Question22
 Copyright   : Edges For Training
 Description : Check an array by applying a threshold to an existing array
[Using array functions]

 ============================================================================
 */

let numbers = [1, 2, 3, 4, 5];
let evenNumbers = numbers.filter(function (num) {
  return num % 2 === 0;
});
console.log(evenNumbers); // [2, 4]
