/*
 ============================================================================
 Name        : Question10
 Copyright   : Edges For Training
 Description : Loop through object properties
 ============================================================================
 */

let animal = { species: "Cat", age: 3, color: "Black" };
for (let key in animal) {
  console.log(key + ": " + animal[key]);
}
// Output:
// species: Cat
// age: 3
// color: Black
