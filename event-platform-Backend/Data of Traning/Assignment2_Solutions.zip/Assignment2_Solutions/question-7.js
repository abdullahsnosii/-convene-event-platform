/*
 ============================================================================
 Name        : Question7    
 Copyright   : Edges For Training
 Description : Capitalize the First Letter of Each Word
 ============================================================================
 */

// Define a sentence
let sentence = "javascript is awesome.";

// Use .split(" ") to split the sentence into an array of words
let words = sentence.split(" ");

// Loop through the words array
for (let i = 0; i < words.length; i++) {
  // Capitalize the first letter of each word and concatenate the rest of the word
  words[i] = words[i][0].toUpperCase() + words[i].slice(1);
}

// Use .join(" ") to join the capitalized words back into a sentence
let capitalizedSentence = words.join(" ");

// Print the capitalized sentence
console.log(capitalizedSentence); // Output: "Javascript Is Awesome."
