/*
 ============================================================================
 Name        : Question15
 Copyright   : Edges For Training
 Description : Accessing an object
 ============================================================================
 */

let person = { name: "Alice", age: 25 };
console.log(person.name); // Dot notation: Alice
console.log(person["age"]); // Bracket notation: 25
