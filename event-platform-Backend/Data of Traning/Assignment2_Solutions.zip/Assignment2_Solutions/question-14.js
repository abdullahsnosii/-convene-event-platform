/*
 ============================================================================
 Name        : Question14
 Copyright   : Edges For Training
 Description : Convert an object into JSON and vice versa
 ============================================================================
 */

let jsonString = '{"name": "John", "age": 25}';
let user = JSON.parse(jsonString);
console.log(user.name); // John

let car = { make: "Tesla", model: "Model 3", year: 2021 };
let newJsonString = JSON.stringify(car);
console.log(newJsonString);
// {"make":"Tesla","model":"Model 3","year":2021}
