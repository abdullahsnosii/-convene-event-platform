/*
 ============================================================================
 Name        : Question20
 Copyright   : Edges For Training
 Description : Find index of an element [Using array functions]
 ============================================================================
 */

let animals = ["Cat", "Dog", "Elephant", "Lion", "Tiger"];
console.log(animals.indexOf("Dog")); // 1
console.log(animals.indexOf("Dolphin")); // -1 (not found)
