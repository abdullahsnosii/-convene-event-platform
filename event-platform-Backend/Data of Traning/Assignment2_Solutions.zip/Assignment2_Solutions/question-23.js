/*
 ============================================================================
 Name        : Question23
 Copyright   : Edges For Training
 Description : Explain the difference between slice() and splice()
 ============================================================================
 */

let arr = ["a", "b", "c", "d"];

// slice
let slicedArr = arr.slice(1, 3); // ['b', 'c']
console.log(slicedArr); // Does not modify the original array

// splice
arr.splice(1, 2); // Removes 2 elements starting from index 1, Affected the original array
console.log(arr); // ['a', 'd']
