/*
 ============================================================================
 Name        : Question16
 Copyright   : Edges For Training
 Description : Accessing array
 ============================================================================
 */

let fruits = ["Apple", "Banana", "Cherry", "Pineapple", "Orange"];
console.log(fruits[0]); // Apple (first element)
console.log(fruits[fruits.length - 1]); // Cherry (last element)
