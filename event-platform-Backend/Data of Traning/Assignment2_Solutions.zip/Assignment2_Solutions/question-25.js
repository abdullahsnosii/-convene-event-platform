/*
 ============================================================================
 Name        : Question25
 Copyright   : Edges For Training
 Description : Filter and Map Transformation
 ============================================================================
 */

function getPassedStudents(students) {
  return students
    .filter((student) => student.score >= 60)
    .map((student) => student.name);
}

const students = [
  { name: "Alice", score: 58 },
  { name: "Bob", score: 72 },
  { name: "Charlie", score: 63 },
  { name: "David", score: 45 },
];

console.log(getPassedStudents(students)); // ['Bob', 'Charlie']
