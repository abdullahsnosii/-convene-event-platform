/*
 ============================================================================
 Name        : Question28
 Copyright   : Edges For Training
 Description : Flatten a Nested Array
 ============================================================================
 */

function flattenArray(arr) {
  return arr.reduce(
    (flat, toFlatten) =>
      flat.concat(
        Array.isArray(toFlatten) ? flattenArray(toFlatten) : toFlatten
      ),
    []
  );
}

const nestedArray = [1, [2, [3, [4, 5]]], 6];
console.log(flattenArray(nestedArray)); // [1, 2, 3, 4, 5, 6]
