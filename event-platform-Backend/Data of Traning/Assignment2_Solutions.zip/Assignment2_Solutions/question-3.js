/*
 ============================================================================
 Name        : Question3    
 Copyright   : Edges For Training
 Description : Extract the First Word from a Sentence
 ============================================================================
 */

// Define a sentence variable
let sentence = "Learning JavaScript is fun!";

// Find the index of the first space and extract the first word using .slice()
let firstWord = sentence.slice(0, sentence.indexOf(" "));

// Print the first word
console.log(firstWord); // Output: "Learning"
