/*
 ============================================================================
 Name        : Question27
 Copyright   : Edges For Training
 Description : Array of Unique Values
 ============================================================================
 */

function groupByFrequency(arr) {
  return arr.reduce((acc, num) => {
    acc[num] = (acc[num] || 0) + 1;
    return acc;
  }, {});
}

const numbers = [1, 2, 2, 3, 3, 3, 4];
console.log(groupByFrequency(numbers));
// { 1: 1, 2: 2, 3: 3, 4: 1 }
