/*
 ============================================================================
 Name        : Question6   
 Copyright   : Edges For Training
 Description : Reverse a String
 ============================================================================
 */

// Define a string
let text = "JavaScript";

// Use .split("") to convert the string into an array of characters
// Then use .reverse() to reverse the array and .join("") to join it back into a string
let reversedText = text.split("").reverse().join("");

// Print the reversed string
console.log(reversedText); // Output: "tpircSavaJ"
