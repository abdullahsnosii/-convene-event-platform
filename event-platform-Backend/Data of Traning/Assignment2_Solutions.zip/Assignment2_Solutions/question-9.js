/*
 ============================================================================
 Name        : Question9
 Copyright   : Edges For Training
 Description : Adding and Deleting from an object
 ============================================================================
 */

let book = { title: "1984", author: "George Orwell" };
book.year = 1949; // Adding a new property
delete book.author; // Deleting a property
console.log(book); // { title: '1984', year: 1949 }
