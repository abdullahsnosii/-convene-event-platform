/*
 ============================================================================
 Name        : Question8    
 Copyright   : Edges For Training
 Description : Find and Replace All Occurrences of a Word
 ============================================================================
 */

// Define a sentence with repeated occurrences of the word "fun"
let sentence = "Learning JavaScript is fun! JavaScript makes coding fun!";

// Use .replace() with a regular expression /fun/g to replace all occurrences of "fun" with "awesome"
let newSentence = sentence.replace(/fun/g, "awesome");

// Print the updated sentence
console.log(newSentence);
// Output: "Learning JavaScript is awesome! JavaScript makes coding awesome!"
