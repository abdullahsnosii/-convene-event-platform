/*
 ============================================================================
 Name        : Question11
 Copyright   : Edges For Training
 Description : Object Destructuring
 ============================================================================
 */

let user = { username: "john_doe", email: "john@example.com", age: 30 };
let { username, email } = user;
console.log(username); // john_doe
console.log(email); // john@example.com
