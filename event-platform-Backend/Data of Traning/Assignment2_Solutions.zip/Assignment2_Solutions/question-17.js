/*
 ============================================================================
 Name        : Question17
 Copyright   : Edges For Training
 Description : Add and remove elements (End of the array)
 ============================================================================
 */

let numbers = [1, 2, 3, 4, 5];
numbers.push(6); // Adds 6 to the end
numbers.pop(); // Removes the last element (6)
