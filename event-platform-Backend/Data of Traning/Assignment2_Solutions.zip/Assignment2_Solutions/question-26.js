/*
 ============================================================================
 Name        : Question26
 Copyright   : Edges For Training
 Description : Array of Unique Values
 ============================================================================
 */

function getUniqueElements(arr1, arr2) {
  return [
    ...arr1.filter((x) => !arr2.includes(x)),
    ...arr2.filter((x) => !arr1.includes(x)),
  ];
}

const arr1 = [1, 2, 3, 4];
const arr2 = [3, 4, 5, 6];

console.log(getUniqueElements(arr1, arr2)); // [1, 2, 5, 6]
