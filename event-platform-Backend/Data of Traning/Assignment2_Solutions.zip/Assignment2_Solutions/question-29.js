/*
 ============================================================================
 Name        : Question29
 Copyright   : Edges For Training
 Description : Sort an Array of Objects by Multiple Criteria
 ============================================================================
 */

function sortByAgeAndName(people) {
  return people.sort((a, b) => {
    if (a.age === b.age) {
      return a.name.localeCompare(b.name);
    }
    return a.age - b.age;
  });
}

const people = [
  { name: "John", age: 25 },
  { name: "Jane", age: 22 },
  { name: "Bob", age: 25 },
  { name: "Alice", age: 22 },
];

console.log(sortByAgeAndName(people));
// [
//   { name: 'Alice', age: 22 },
//   { name: 'Jane', age: 22 },
//   { name: 'Bob', age: 25 },
//   { name: 'John', age: 25 }
// ]
