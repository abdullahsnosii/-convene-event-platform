/*
 ============================================================================
 Name        : Question18
 Copyright   : Edges For Training
 Description : Add and remove elements (Beginning of the array)
 ============================================================================
 */

let colors = ["Red", "Green", "Blue", "Black", "White"];
colors.unshift("Yellow"); // Adds 'Yellow' to the beginning
colors.shift(); // Removes the first element ('Yellow')
