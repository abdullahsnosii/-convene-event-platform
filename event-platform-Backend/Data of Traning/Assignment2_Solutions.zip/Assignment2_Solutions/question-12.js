/*
 ============================================================================
 Name        : Question12
 Copyright   : Edges For Training
 Description : Create an object with two methods
 ============================================================================
 */

let sum = {
  default1: 3,
  default2: 4,
  normalSum: function (x, y) {
    if (x && y) {
      return x + y;
    } else {
      return this.default1 + this.default2;
    }
  },
  anonymousSum: (x, y) => {
    if (x && y) {
      return x + y;
    } else {
      return this.default1 + this.default2;
    }
  },
};

console.log(sum.normalSum(5, 6)); // Returns 11
console.log(sum.normalSum()); // Returns 7

console.log(sum.anonymousSum(5, 6)); // Returns 11
console.log(sum.anonymousSum()); // Returns undefined
