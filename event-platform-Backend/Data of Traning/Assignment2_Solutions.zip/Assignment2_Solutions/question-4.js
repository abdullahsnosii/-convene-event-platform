/*
 ============================================================================
 Name        : Question4    
 Copyright   : Edges For Training
 Description : Check if a String Contains a Specific Word
 ============================================================================
 */

// Define a sentence
let sentence = "I am learning JavaScript.";

// Check if the word "JavaScript" is included in the sentence using .includes()
if (sentence.includes("JavaScript")) {
  // If true, print a message
  console.log("The word 'JavaScript' is present.");
} else {
  // If false, print a different message
  console.log("The word 'JavaScript' is not present.");
}
