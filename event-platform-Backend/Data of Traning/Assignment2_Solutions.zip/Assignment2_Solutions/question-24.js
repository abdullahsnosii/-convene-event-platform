/*
 ============================================================================
 Name        : Question24
 Copyright   : Edges For Training
 Description : Find sum of all array numbers [Using array functions]
 ============================================================================
 */

const arr = [1, 2, 3, 4, 5];

const result = arr.reduce((acc, res) => {
  return (acc += res);
}, 0);

console.log(result); // 15
