/*
 ============================================================================
 Name        : Question19
 Copyright   : Edges For Training
 Description : Loop through an array
 ============================================================================
 */

const arr = [1, 2, 3, 4, 5];

for (let i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}

for (let i of arr) {
  console.log(i);
}

for (let i in arr) {
  console.log(arr[i]);
}
