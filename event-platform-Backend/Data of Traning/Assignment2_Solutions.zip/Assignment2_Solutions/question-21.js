/*
 ============================================================================
 Name        : Question21
 Copyright   : Edges For Training
 Description : Create an array by transforming each element of an existing array 
[Using array functions]

 ============================================================================
 */

let numbers = [1, 2, 3, 4, 5];
let newArr = numbers.map(function (num) {
  return num + 2;
});
console.log(newArr); // [3, 4, 5, 6, 7]
