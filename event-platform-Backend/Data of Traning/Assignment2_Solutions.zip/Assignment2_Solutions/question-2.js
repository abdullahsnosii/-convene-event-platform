/*
 ============================================================================
 Name        : Question2
 Copyright   : Edges For Training
 Description : Convert a String to Uppercase
 ============================================================================
 */

// Define a string variable
let text = "javascript is fun!";

// Convert the string to uppercase using .toUpperCase() and store in a new variable
let upperText = text.toUpperCase();

// Print the uppercase string
console.log(upperText); // Output: "JAVASCRIPT IS FUN!"
