/*
 ============================================================================
 Name        : Question5    
 Copyright   : Edges For Training
 Description : Count the Occurrences of a Character in a String
 ============================================================================
 */

// Define a string
let text = "JavaScript is amazing!";

// Define the character to count
let char = "a";

// Initialize a counter to store the number of occurrences
let count = 0;

// Loop through the string character by character
for (let i = 0; i < text.length; i++) {
  // If the current character matches the target character, increment the counter
  if (text[i] === char) {
    count++;
  }
}

// Print the final count
console.log(`The character "${char}" appears ${count} times.`); // Output: 3
