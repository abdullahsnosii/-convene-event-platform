/*
 ============================================================================
 Name        : Question13
 Copyright   : Edges For Training
 Description : Cloning an object
 ============================================================================
 */

let original = { name: "Alice", age: 25 };

// Method 1: Object.assign
let clone1 = Object.assign({}, original);

// Method 2: Spread operator
let clone2 = { ...original };

console.log(clone1); // { name: 'Alice', age: 25 }
console.log(clone2); // { name: 'Alice', age: 25 }
