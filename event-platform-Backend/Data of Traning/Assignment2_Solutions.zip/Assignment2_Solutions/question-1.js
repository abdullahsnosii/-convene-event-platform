/*
 ============================================================================
 Name        : Question1
 Copyright   : Edges For Training
 Description : Print the Length of a String 
 ============================================================================
 */

// Define a string variable
let message = "Hello, world!";

// Get and print the length of the string using the .length property
console.log(message.length); // Output: 13
