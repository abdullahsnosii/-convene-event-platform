      // Browser-specific APIs
      console.log("Hello from Browser Runtime!");

      // Accessing DOM (only available in browser)
      document.body.style.backgroundColor = "lightblue";

      // Using Fetch API (provided by browser)
      fetch("https://jsonplaceholder.typicode.com/todos/1")
        .then(response => response.json())
        .then(data => console.log("Fetched Data:", data));

      // Using LocalStorage (browser feature)
      localStorage.setItem("username", "Omar");
      console.log("Saved in LocalStorage:", localStorage.getItem("username"));
