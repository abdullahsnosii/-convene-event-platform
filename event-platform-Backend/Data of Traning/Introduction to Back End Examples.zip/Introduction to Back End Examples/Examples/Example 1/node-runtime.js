// Node-specific APIs
console.log("Hello from Node.js Runtime!");

// Using process (Node global object)
console.log("Process Platform:", process.platform);

// Using fs module (File System)
const fs = require("fs");

// Write to a file
fs.writeFileSync("example.txt", "This file was created by Node.js!");
console.log("File written successfully!");

// Read the file
const data = fs.readFileSync("example.txt", "utf-8");
console.log("File content:", data);

// Using http module (create simple server)
const http = require("http");
const server = http.createServer((req, res) => {
  res.end("Hello, this is Node.js server response!");
});

server.listen(3000, () => {
  console.log("Server is running at http://localhost:3000");
});
