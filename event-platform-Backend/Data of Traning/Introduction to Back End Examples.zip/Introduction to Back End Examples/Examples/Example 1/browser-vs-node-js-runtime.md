# Browser Runtime vs Node.js Runtime
---

### Example 1 – Code that **works in the Browser**

```html
<!DOCTYPE html>
<html>
  <body>
    <h1>Browser Runtime Example</h1>
    <script>
      // Browser-specific APIs
      console.log("Hello from Browser Runtime!");

      // Accessing DOM (only available in browser)
      document.body.style.backgroundColor = "lightblue";

      // Using Fetch API (provided by browser)
      fetch("https://jsonplaceholder.typicode.com/todos/1")
        .then(response => response.json())
        .then(data => console.log("Fetched Data:", data));

      // Using LocalStorage (browser feature)
      localStorage.setItem("username", "Omar");
      console.log("Saved in LocalStorage:", localStorage.getItem("username"));
    </script>
  </body>
</html>
```

👉 Run this in a browser:

* It changes the background color (via `document`).
* Saves data in `localStorage`.
* Uses `fetch` to call an API.

⚠️ If you try this in **Node.js**, it will fail because **`document`, `window`, `fetch`, and `localStorage` don’t exist** there.

---

### Example 2 – Code that **works in Node.js**

```js
// Save this as node_example.js and run with: node node_example.js

// Node-specific APIs
console.log("Hello from Node.js Runtime!");

// Using process (Node global object)
console.log("Process Platform:", process.platform);

// Using fs module (File System)
const fs = require("fs");

// Write to a file
fs.writeFileSync("example.txt", "This file was created by Node.js!");
console.log("File written successfully!");

// Read the file
const data = fs.readFileSync("example.txt", "utf-8");
console.log("File content:", data);

// Using http module (create simple server)
const http = require("http");
const server = http.createServer((req, res) => {
  res.end("Hello, this is Node.js server response!");
});

server.listen(3000, () => {
  console.log("Server is running at http://localhost:3000");
});
```

👉 Run this with Node:

* It prints process info.
* Creates a file using `fs`.
* Starts a simple HTTP server.

⚠️ If you try this in the **browser console**, it will fail because **`require`, `fs`, and `http` don’t exist** there.

---

### 🔑 Key Takeaway for Students:

* **Browser Runtime** = JS Engine + `window` (DOM, fetch, localStorage, etc.).
* **Node.js Runtime** = JS Engine + `global` (process, console, timers) + built-in modules (`fs`, `http`, `net`, …).

👉 Same **JavaScript language**, but **different host environments** provide different APIs.
