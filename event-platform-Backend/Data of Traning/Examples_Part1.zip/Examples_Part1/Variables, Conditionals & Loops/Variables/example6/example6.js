/*
 ============================================================================
 Name        : Exercise6
 Copyright   : Edges For Training
 Description : This script demonstrates increment and decrement operators:
                * - Post-increment (x++) and Pre-increment (++x)
                * - Post-decrement (x--) and Pre-decrement (--x)
 ============================================================================
 */

let count = 5;

console.log(count++); // 5 (returns first, then increases)
console.log(count); // 6

console.log(++count); // 7 (increases first, then returns)

console.log(count--); // 7 (returns first, then decreases)
console.log(count); // 6

console.log(--count); // 5 (decreases first, then returns)
