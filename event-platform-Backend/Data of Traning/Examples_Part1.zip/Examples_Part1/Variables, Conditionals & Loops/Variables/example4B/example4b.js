/*
 ============================================================================
 Name        : Exercise4B
 Copyright   : Edges For Training
 Description : This script demonstrates how non-primitive data types (objects and arrays)
                are stored by reference, meaning changes to one reference affect the original data.
 ============================================================================
 */

// Example 1: Objects (Stored by Reference)
let person = { name: "Alice", age: 25 };
let anotherPerson = person; // anotherPerson points to the same object

anotherPerson.age = 30; // Modifying anotherPerson also affects person

console.log("Original Person:", person); // { name: "Alice", age: 30 }
console.log("Another Person:", anotherPerson); // { name: "Alice", age: 30 }

// Example 2: Arrays (Stored by Reference)
let numbers = [1, 2, 3];
let anotherNumbers = numbers; // anotherNumbers points to the same array

anotherNumbers.push(4); // Modifying anotherNumbers also affects numbers

console.log("Original Numbers:", numbers); // [1, 2, 3, 4]
console.log("Another Numbers:", anotherNumbers); // [1, 2, 3, 4]
