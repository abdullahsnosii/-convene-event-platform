/*
 ============================================================================
 Name        : Exercise8    
 Copyright   : Edges For Training
 Description : This script demonstrates how JavaScript handles operations between strings and numbers:
                * - Implicit type conversion (string + number)
                * - Explicit conversion using Number()
 ============================================================================
 */

let num1 = "10"; // String
let num2 = 5; // Number

console.log(num1 + num2); // "105" (string + number = string)
console.log(num1 - num2); // 5 ("10" is converted to number)
console.log(num1 * num2); // 50 ("10" is converted to number)
console.log(num1 / num2); // 2 ("10" is converted to number)

// Explicit conversion
console.log(Number(num1) + num2); // 15 (correct addition)
