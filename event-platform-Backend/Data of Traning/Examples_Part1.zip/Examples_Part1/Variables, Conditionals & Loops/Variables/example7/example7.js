/*
 ============================================================================
 Name        : Exercise7
 Copyright   : Edges For Training
 Description : This script demonstrates:
                * - Operator precedence (order of execution)
                * - Using parentheses to control execution order
                * - Exponentiation (**)
                * - Modulus (%)
 ============================================================================
 */

let x = 2;
let y = 3;
let z = 4;

let result1 = x + y * z; // 2 + (3 * 4) = 14 (Multiplication first)
let result2 = (x + y) * z; // (2 + 3) * 4 = 20 (Parentheses first)
let result3 = x ** y; // 2³ = 8 (Exponentiation)
let result4 = z % y; // 4 % 3 = 1 (Remainder)

console.log("Without parentheses:", result1);
console.log("With parentheses:", result2);
console.log("Exponentiation:", result3);
console.log("Modulus:", result4);
