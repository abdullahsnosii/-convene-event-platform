/*
 ============================================================================
 Name        : Exercise4
 Copyright   : Edges For Training
 Description : This script demonstrates different JavaScript data types:
                * - Numbers
                * - Strings
                * - Booleans
                * - Undefined
                * - Null
                * - Using typeof to check data types
 ============================================================================
 */

let age = 25; // Number
let name = "Alice"; // String
let isStudent = true; // Boolean
let address; // Undefined (not assigned)
let emptyValue = null; // Null (intentional empty value)

console.log(typeof age); // "number"
console.log(typeof name); // "string"
console.log(typeof isStudent); // "boolean"
console.log(typeof address); // "undefined"
console.log(typeof emptyValue); // "object" (special case in JS)
