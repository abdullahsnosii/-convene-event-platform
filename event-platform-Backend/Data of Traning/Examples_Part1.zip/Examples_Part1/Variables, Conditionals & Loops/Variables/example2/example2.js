/*
 ============================================================================
 Name        : Exercise2
 Copyright   : Edges For Training
 Description : Variables explanation
 ============================================================================
 */

// Declare a variable 'score' and initialize it with a value of 100
let score = 100;
// Output the initial value of 'score' to the console
console.log(score);

// Change the value of 'score' to 200
score = 200;
// Output the updated value of 'score' to the console
console.log(score);

// Declare a constant 'birthYear' and initialize it with a value of 1990
const birthYear = 1990;
// Output the value of 'birthYear' to the console
console.log(birthYear);

// Attempt to change the value of 'birthYear' to 2001
// This line will cause an error since constants cannot be reassigned
birthYear = 2001; // Error: Assignment to constant variable
// Output the value of 'birthYear' to the console (this line won't be reached due to the error)
console.log(birthYear);
