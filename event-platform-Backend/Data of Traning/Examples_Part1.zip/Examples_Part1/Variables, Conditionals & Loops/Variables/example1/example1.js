/*
 ============================================================================
 Name        : Exercise1
 Copyright   : Edges For Training
 Description : Variables explanation
 ============================================================================
 */

let age = 25; // A variable that can change
age = 30;

const name = "John"; // A constant, value cannot be changed
name = "Doe";

var city = "New York"; // An older way of declaring variables (not recommended in modern JavaScript)
city = "San Francisco";

const pi = 3.14159; // Constant value
