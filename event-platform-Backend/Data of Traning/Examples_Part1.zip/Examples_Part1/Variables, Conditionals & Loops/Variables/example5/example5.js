/*
 ============================================================================
 Name        : Exercise5
 Copyright   : Edges For Training
 Description : This script demonstrates basic arithmetic operations in JavaScript:
                * - Addition (+)
                * - Subtraction (-)
                * - Multiplication (*)
                * - Division (/)
                * - Modulus (%) - remainder of a division
 ============================================================================
 */

let a = 10;
let b = 4;

console.log("Addition:", a + b); // 14
console.log("Subtraction:", a - b); // 6
console.log("Multiplication:", a * b); // 40
console.log("Division:", a / b); // 2.5
console.log("Modulus:", a % b); // 2 (remainder when 10 is divided by 4)
