/*
 ============================================================================
 Name        : Exercise3
 Copyright   : Edges For Training
 Description : Variables explanation
 ============================================================================
 */

{
  let x = 10;
}
console.log(x);
