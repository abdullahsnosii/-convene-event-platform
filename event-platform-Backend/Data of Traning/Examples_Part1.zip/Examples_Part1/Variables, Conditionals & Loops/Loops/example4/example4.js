/*
 ============================================================================
 Name        : Exercise4
 Copyright   : Edges For Training
 Description : This program calculates the sum of numbers from 1 to 5
 ============================================================================
 */

let sum = 0;

for (let i = 1; i <= 5; i++) {
  sum += i; // Add i to sum
}

console.log("Sum:", sum);

// Output:
// Sum: 15
