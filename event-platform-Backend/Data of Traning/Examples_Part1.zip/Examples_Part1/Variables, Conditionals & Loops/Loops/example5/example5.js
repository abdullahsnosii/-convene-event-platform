/*
 ============================================================================
 Name        : Exercise5
 Copyright   : Edges For Training
 Description : Printing every even number from 1 to 10
 ============================================================================
 */

for (let i = 0; i <= 10; i++) {
  if (i % 2 == 0) {
    console.log(i);
  }
}
