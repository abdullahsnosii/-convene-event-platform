/*
 ============================================================================
 Name        : Exercise1
 Copyright   : Edges For Training
 Description : Printing hello 3 times using a while loop    
 ============================================================================
 */

let i = 0; // start looping at 0

// Start a while loop that continues as long as 'i' is less than 3
while (i < 3) {
  // Output 'Hello' to the console
  console.log("Hello");

  // Increment the value of 'i' by 1 to avoid an infinite loop
  i++;
}
