/*
 ============================================================================
 Name        : Exercise2
 Copyright   : Edges For Training
 Description : While loop with count down  
 ============================================================================
 */

// count down from 5 to 1
let num = 5; // start looping at 0
while (num > 0) {
  // keep going as long as number is greater than 0
  console.log(num);
  num--; // Decrement by 1 each loop iteration
}
