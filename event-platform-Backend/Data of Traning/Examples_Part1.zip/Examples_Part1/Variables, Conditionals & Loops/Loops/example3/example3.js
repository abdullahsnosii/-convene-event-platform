/*
 ============================================================================
 Name        : Exercise3
 Copyright   : Edges For Training
 Description : Powering a number to a certain power
 ============================================================================
 */

let x = 10;
let y = 3; // The value of 'y' will be decremented in the loop

// This will hold the result of x raised to the power of y
let power = 1;

// Start a while loop that continues as long as 'y' is greater than 0
while (y > 0) {
  power *= x;
  y--; // Decrement 'y' by 1 in each iteration to eventually exit the loop
}

// Output the result of 'x' raised to the power 'y' (10^2 in this case)
console.log(power);
