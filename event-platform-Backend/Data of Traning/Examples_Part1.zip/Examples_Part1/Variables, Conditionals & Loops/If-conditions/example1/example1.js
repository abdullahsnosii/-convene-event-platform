/*
 ============================================================================
 Name        : Exercise1
 Copyright   : Edges For Training
 Description : This script checks the temperature and prints a message based on its value.
 ============================================================================
 */

// Declare a variable 'temperature' and initialize it with a value of 30
let temperature = 30;

// Check if 'temperature' is greater than 25
if (temperature > 25) {
  // If the condition is true, output 'It is hot!' to the console
  console.log("It is hot!");
} else {
  // If the condition is false (temperature is 25 or less), output 'It is cool.' to the console
  console.log("It is cool.");
}
