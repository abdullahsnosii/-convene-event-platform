/*
 ============================================================================
 Name        : Exercise2
 Copyright   : Edges For Training
 Description : This script checks if the number is even or odd
 ============================================================================
 */

// Declare a variable 'number' and initialize it with a value of 7
let number = 7;

// Check if 'number' is even by using the modulo operator
// The modulo operator (%) returns the remainder of the division of 'number' by 2
// If 'number' is even, the remainder will be 0
if (number % 2 === 0) {
  // If the condition is true (the number is even), output 'Even' to the console
  console.log("Even");
} else {
  // If the condition is false (the number is odd), output 'Odd' to the console
  console.log("Odd");
}
