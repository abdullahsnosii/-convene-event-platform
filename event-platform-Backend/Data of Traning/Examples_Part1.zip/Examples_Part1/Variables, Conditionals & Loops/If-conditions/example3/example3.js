/*
 ============================================================================
 Name        : Exercise3
 Copyright   : Edges For Training
 Description : This script assigns a numeric grade and determines the corresponding letter grade using conditional statements.
 ============================================================================
 */

// Declare a variable 'grade' and initialize it with a value of 98
let grade = 98;

// Check if 'grade' is greater than 87
if (grade > 87) {
  // If true, output "A" to the console
  console.log("A");
}
// If the previous condition is false, check if 'grade' is greater than 80
else if (grade > 80) {
  // If true, output "B" to the console
  console.log("B");
}
// If both previous conditions are false, check if 'grade' is greater than 70
else if (grade > 70) {
  // If true, output "C" to the console
  console.log("C");
}
// If all previous conditions are false, check if 'grade' is greater than 60
else if (grade > 60) {
  // If true, output "D" to the console
  console.log("D");
}
// If none of the above conditions are true, it means the grade is 60 or lower
else {
  // Output "F" to the console
  console.log("F");
}
