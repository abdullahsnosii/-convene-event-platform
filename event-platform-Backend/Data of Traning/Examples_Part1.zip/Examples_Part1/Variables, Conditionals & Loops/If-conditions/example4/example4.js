/*
 ============================================================================
 Name        : Exercise4
 Copyright   : Edges For Training
 Description : This script calculates the Body Mass Index (BMI) based on weight and height, then categorizes the result as underweight, fit, or overweight.
 ============================================================================
 */

// Declare a variable 'weight' and initialize it with a value of 110 (in kilograms)
let weight = 110;

// Declare a variable 'height' and initialize it with a value of 190 (in centimeters)
let height = 190;

// Calculate BMI using the formula: weight (kg) / (height (m) * height (m))
// Convert height from centimeters to meters by dividing by 100
height = height / 100;
let bmi = weight / (height * height);

// Check the value of BMI and categorize the result
if (bmi < 18.5) {
  // If BMI is less than 18.5, output that the person is underweight
  console.log("You are underweight");
} else if (bmi < 25) {
  // If BMI is between 18.5 and 25, output that the person is fit
  console.log("You are fit");
} else {
  // If BMI is 25 or higher, output that the person is overweight
  console.log("You are overweight");
}
