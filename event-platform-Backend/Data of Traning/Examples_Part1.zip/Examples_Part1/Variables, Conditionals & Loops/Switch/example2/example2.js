/*
 ============================================================================
 Name        : Exercise2
 Copyright   : Edges For Training
 Description : Traffic light    
 ============================================================================
 */

// Declare a variable 'trafficLight' and initialize it with the string 'red'
let trafficLight = "red";

// Use a switch statement to evaluate the value of 'trafficLight'
switch (trafficLight) {
  // Case for when 'trafficLight' is 'red'
  case "red":
    // If the case matches, output 'Stop' to the console
    console.log("Stop");
    // Exit the switch block
    break;

  // Case for when 'trafficLight' is 'yellow'
  case "yellow":
    // If the case matches, output 'Caution' to the console
    console.log("Caution");
    // Exit the switch block
    break;

  // Case for when 'trafficLight' is 'green'
  case "green":
    // If the case matches, output 'Go' to the console
    console.log("Go");
    // Exit the switch block
    break;

  // Default case if none of the above cases match
  default:
    // If 'trafficLight' is not 'red', 'yellow', or 'green', output 'Invalid signal' to the console
    console.log("Invalid signal");
}
