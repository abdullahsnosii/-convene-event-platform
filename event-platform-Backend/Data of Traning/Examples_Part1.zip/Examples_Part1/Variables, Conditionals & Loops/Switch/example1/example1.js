/*
 ============================================================================
 Name        : Exercise1
 Copyright   : Edges For Training
 Description : Grade calculator
 ============================================================================
 */

// Declare a variable 'grade' and initialize it with the string 'A'
let grade = "a";

// Use a switch statement to evaluate the value of 'grade'
switch (grade) {
  // Case for when 'grade' is 'A'
  case "A":
    // If the case matches, output 'Excellent' to the console
    console.log("Excellent");
    // Exit the switch block
    break;

  // Case for when 'grade' is 'B'
  case "B":
    // If the case matches, output 'Good' to the console
    console.log("Good");
    // Exit the switch block
    break;

  // Case for when 'grade' is 'C'
  case "C":
    // If the case matches, output 'Fair' to the console
    console.log("Fair");
    // Exit the switch block
    break;

  // Default case if none of the above cases match
  default:
    // If 'grade' is not 'A', 'B', or 'C', output 'Unknown grade' to the console
    console.log("Unknown grade");
}
