/*
 ============================================================================
 Name        : Exercise1
 Copyright   : Edges For Training
 Description : Functions that determines whether a number is even or odd
 ============================================================================
 */

// Declare a function 'isEvenOrOdd' that takes a single parameter 'num'
function isEvenOrOdd(num) {
  // Check if the number is divisible by 2 using the modulo operator (%)
  // If 'num % 2' equals 0, the number is even
  if (num % 2 === 0) {
    // Return 'Even' if the condition is true
    return "Even";
  } else {
    // Otherwise, return 'Odd' if the condition is false
    return "Odd";
  }
}

// Call the 'isEvenOrOdd' function with the number 4 and log the result
console.log(isEvenOrOdd(4)); // Output: Even

// Call the 'isEvenOrOdd' function with the number 7 and log the result
console.log(isEvenOrOdd(7)); // Output: Odd
