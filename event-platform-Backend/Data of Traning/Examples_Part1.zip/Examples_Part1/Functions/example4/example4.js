/*
 ============================================================================
 Name        : Exercise4
 Copyright   : Edges For Training
 Description : Function returning a function
 ============================================================================
 */

function multiplier(factor) {
  function multiply(number) {
    return number * factor;
  }
  return multiply;
}

const double = multiplier(2);
console.log(double(5)); // Output: 10
