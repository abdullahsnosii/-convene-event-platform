/*
 ============================================================================
 Name        : Exercise5
 Copyright   : Edges For Training
 Description : Higher order function
 ============================================================================
 */

function applyOperation(a, b, operation) {
  return operation(a, b);
}

function add(x, y) {
  return x + y;
}

function subtract(x, y) {
  return x - y;
}

console.log(applyOperation(10, 5, add)); // Output: 15
console.log(applyOperation(10, 5, subtract)); // Output: 5
