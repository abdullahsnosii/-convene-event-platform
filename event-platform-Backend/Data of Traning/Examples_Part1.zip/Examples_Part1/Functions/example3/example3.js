/*
 ============================================================================
 Name        : Exercise3
 Copyright   : Edges For Training
 Description : Prints the multiples of a number
 ============================================================================
 */
function evaluate() {
  return 3;
}

// Declare a function 'printMultiples' that takes two parameters: 'number' and 'limit'
function printMultiples(number, limit) {
  // Use a for loop to iterate from 1 up to 'limit'
  for (let i = 1; i <= limit; i++) {
    // In each iteration, log the multiplication of 'number' by the current value of 'i'
    console.log(number, "x", i, "=", number * i);
  }
  return evaluate;
}

// Call the 'printMultiples' function to print the multiples of 3 up to 10
const result = printMultiples(3, 10);
console.log(result);
