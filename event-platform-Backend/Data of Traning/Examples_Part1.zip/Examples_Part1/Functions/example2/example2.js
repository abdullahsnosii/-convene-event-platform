/*
 ============================================================================
 Name        : Exercise2
 Copyright   : Edges For Training
 Description : Factorial function
 ============================================================================
 */

function factorial(n) {
  // Initialize a variable 'product' with 1
  // This will store the result of the factorial calculation
  let product = 1;

  // Use a for loop to multiply 'product' by every number from 2 up to 'n'
  for (let i = 2; i <= n; i++) {
    // Multiply 'product' by 'i' in each iteration
    product *= i;
  }

  // After the loop finishes, return the calculated factorial
  return product;
}

// Call the 'factorial' function with the value 5 and log the result
console.log(factorial(5)); // Output: 120
